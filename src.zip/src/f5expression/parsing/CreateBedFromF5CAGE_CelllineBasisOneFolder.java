package f5expression.parsing;

import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class CreateBedFromF5CAGE_CelllineBasisOneFolder {

	
	String foldInput;
	String fname;
	String foldOutput;
	int useAnnot;
	
	
	void work1Folder( String curFoldAbsPath, String curFold)
	{
		
		String curFileNameAbs = curFoldAbsPath + "/" + this.fname;
		
		Vector<String> vectAllLines = CommonFunction.readlinesOfAfile(curFileNameAbs);
		
		StringBuffer buf = new StringBuffer();
		String curLine;
		String tmpF5Name[] , tmp[];
		String finalName="", nameProteins, exprValueString;
		int totColumn;
		
		for( int i=0 ; i<vectAllLines.size() ;i++)
		{
 			tmp = ConstantValue.patTab.split(vectAllLines.get(i) );
			totColumn = tmp.length;
			exprValueString = tmp[ totColumn - 1];
 			
			tmpF5Name = ConstantValue.patFantom5Cage.split( tmp[0] ) ;
			
			
			
			if( this.useAnnot ==1)
			{
				
				nameProteins = tmp[1].endsWith(";") ? tmp[1].substring(0 , tmp[1].length() -1 ) : tmp[1];
				finalName = (curFold + ConstantValue.seperatorList + 
						nameProteins 
//							tmp[0]
									);
				
			}else{
				finalName = (curFold ) ; // + ConstantValue.seperatorList  + tmp[0]);
			}
			curLine = 
					tmpF5Name[0] 						+ "\t" + 
					(Integer.parseInt(tmpF5Name[1])-1) 	+ "\t" + 
					tmpF5Name[2]  						+ "\t" + 
					finalName							+ "\t" +
					exprValueString						+ "\t" + 
					tmpF5Name[3]		;
			
			
			buf.append(curLine+"\n");
			
			
			
		}
		
		
//		CommonFunction.writeContentToFile( curFileName + ".bed",  buf+"" );
		
		System.out.println("Writing file: " + this.foldOutput + curFold + ".bed" );
		CommonFunction.writeContentToFile( this.foldOutput + curFold + ".bed",  buf+"" );
		
	}
	
	
	void workAllFolder(String rootFold)
	{
		
		Vector<String> vectAllFold = FolderOperations.listFiles_Dir( rootFold );
		String curFold;
		for( int i=0 ; i<vectAllFold.size() ;i++)
		{
			curFold = vectAllFold.get(i);
			
			System.out.println( rootFold + "/" + curFold + "/");
			
			work1Folder( rootFold + "/" +  curFold  + "/" , curFold);
			
		}
		
	}
	
	
	void doProcessing()
	{
	
		FolderOperations.create_new_folder( this.foldOutput);
		
		workAllFolder( this.foldInput);
	}
	
	
	
	
	
	



	public CreateBedFromF5CAGE_CelllineBasisOneFolder(String foldInput, String fname,
			String foldOutput, int useAnnot) {
		super();
		this.foldInput = foldInput;
		this.fname = fname;
		this.foldOutput = foldOutput;
		this.useAnnot = useAnnot;
	}


	public static void main(String[] args) {
	
		
		CreateBedFromF5CAGE_CelllineBasisOneFolder obj = new CreateBedFromF5CAGE_CelllineBasisOneFolder( args[0] , args[1] , args[2] , Integer.parseInt( args[3]  ) );
		
		
//		CreateBedFromF5CAGE_CelllineBasis obj = new CreateBedFromF5CAGE_CelllineBasis( "./splitPublicAnnotMerged/" , 
//				"merged.txt" , 
//				"./splitPublicAnnotMergedBed/",
//				Integer.parseInt("1")
//				);
		
		obj.doProcessing();
		
	}
	
	
}
