package f5expression.parsing;

import java.util.Arrays;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class MergeDifferentReplicas {



	String fnmSampleInfoTSV;
	String foldAllData;
	String foldOut;
	String type;


	Vector<String> vectSampleInfo = new Vector<String>();

	void loadSampleInfo()
	{
		String tmp[];
		Vector<String> vectTmp = CommonFunction.readlinesOfAfile(this.fnmSampleInfoTSV);
		for( int i=0 ; i<vectTmp.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectTmp.get(i));
			if(tmp[1].equals( this.type))
			{
				vectSampleInfo.add( vectTmp.get(i ) );
			}

		}

		System.out.println(" For  " + this.type  + " total entry : " + vectSampleInfo.size() );

	}


	void merge1case( String nameCell_Tissue, String sampleIDs)
	{


		FolderOperations.create_new_folder(this.foldOut);
		String curOutFold = this.foldOut + "/"+  nameCell_Tissue;
		FolderOperations.create_new_folder( curOutFold );
		String curOutputFile = curOutFold + "/" + "merged.txt";


		StringBuffer bufMerged = new StringBuffer();
		Vector<String> vectCurLines , vectFirsFile;
		String tmpReplica[];
		String curInputFile;
		tmpReplica = ConstantValue.patHash.split(sampleIDs);
		int totalReplica = tmpReplica.length;

		if( totalReplica ==1) // 1 replica
		{
			curInputFile = this.foldAllData + "/" + tmpReplica[0] + ".txt";

			//			System.out.println( curInputFile);

			FolderOperations.copy_paste_file(curInputFile, curOutputFile );



		}else // Handle Replica
		{

			//			if( nameCell_Tissue.equals("THYROID") ||
			//					nameCell_Tissue.equals("SPINAL CORD" ))

			{




				StringBuffer resBuf = new StringBuffer();
				Vector<String> resVect = new Vector<String>();

				String tmpVal[];

				int noCol;

				/*
				 *  First replica
				 */

				curInputFile = this.foldAllData + "/" + tmpReplica[0] + ".txt";
				vectFirsFile = CommonFunction.readlinesOfAfile( curInputFile);
				int totalCAGEcluster = vectFirsFile.size();
				double expr [][] = new double[ totalCAGEcluster][ totalReplica];

				/*
				 *  Iterate over all replica to load Expr Values
				 */
				System.out.println( nameCell_Tissue + " has  " + totalReplica + "  replicas. ");
				for( int replica=0 ; replica< totalReplica; replica++)
				{

					curInputFile = this.foldAllData + "/" + tmpReplica[ replica ] + ".txt";
//					System.out.println( curInputFile );
					vectCurLines = CommonFunction.readlinesOfAfile( curInputFile);

					for( int line=0 ; line<vectCurLines.size() ;line++)
					{
						tmpVal = ConstantValue.patTab.split(vectCurLines.get( line )) ;
						noCol = tmpVal.length;

						expr[line][ replica ] = Double.parseDouble( tmpVal[noCol-1] );


					}

				}


				/*
				 *  Now write merged file
				 *  
				 */
				bufMerged = new StringBuffer();

				for( int w =0;  w< vectFirsFile.size(); w++)
				{
					String tmp[] = ConstantValue.patTab.split( vectFirsFile.get(w ));
					int tot = tmp.length;
					for(int r= 0 ; r<tot-1;r++)
					{
						bufMerged.append( tmp[r] + "\t" );
					}

					bufMerged.append( getResultFromReplicas( expr[w] )   +  "\n");

				}


			}


			CommonFunction.writeContentToFile( curOutputFile,  bufMerged + "");
			//			System.out.println( "** OUT ** " + curOutputFile );

		}






	}


	String getResultFromReplicas( double replicaValues[])
	{
		int totRep = replicaValues.length;



		StringBuffer result= new StringBuffer();

		for( int i=0 ;  i < replicaValues.length ;i++)
		{

			//			if( i == (replicaValues.length -1) )
			//				result.append( replicaValues[i] );
			//			else
			result.append( replicaValues[i] + "\t");
		}


		Arrays.sort(replicaValues);

		int positionMedian=0;
		if( totRep%2 == 0)
		{
			positionMedian = totRep/2; 
		}else
		{
			positionMedian = totRep/2 +1;
		}
		Math.ceil(  totRep/2.00) ;

		int indexMedian = positionMedian-1;
		result.append( replicaValues[indexMedian  ] + "\t");

		return result + "";
	}

	void mergeAllcase()
	{
		String tmp[];
		String nameCell_Tissue, type, 	sampleIDs;
		for( int i=0 ; i<vectSampleInfo.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectSampleInfo.get(i ));
			nameCell_Tissue = tmp[0];
			type = tmp[1];
			sampleIDs = tmp[2];

			merge1case( nameCell_Tissue, sampleIDs);

		}


	}



	void doProcessing()
	{




		loadSampleInfo();

		mergeAllcase();



	}




	public MergeDifferentReplicas(String fnmSampleInfoTSV, String foldAllData,
			String foldOut, String type) {
		super();
		this.fnmSampleInfoTSV = fnmSampleInfoTSV;
		this.foldAllData = foldAllData;
		this.foldOut = foldOut;
		this.type = type;
	}


	public static void main(String[] args) {


		long startTime   = System.currentTimeMillis();


		MergeDifferentReplicas obj = new MergeDifferentReplicas(args[0], args[1], args[2], args[3]);

		//						MergeDifferentReplicas obj = new MergeDifferentReplicas(
		//								"final.CAGE.sample_info.FANTOM.xlsx.txt.tsv", 
		//								"./splitPublicAnnot", 
		//								"./splitPublicAnnotMerged", 
		//								"primary_cell");


		//		MergeDifferentReplicas obj = new MergeDifferentReplicas(
		//				"final.CAGE.sample_info.FANTOM.xlsx.txt.tsv", 
		//				"./splitPublic", 
		//				"./splitPublicMerged", 
		//				"tissue");


		obj.doProcessing();


		//		MergeDifferentReplicas obj = new MergeDifferentReplicas( "" , "./", "", "");
		//		Vector<String> vectAll = FolderOperations.listFiles_Dir("./") ;
		//		

		long endTime   = System.currentTimeMillis();
		long totalTime = ((endTime - startTime)/((long)1000.0) );
		System.out.println("Total time IN MERGING ALL FILES: " + totalTime + " sec" );


	}

}
