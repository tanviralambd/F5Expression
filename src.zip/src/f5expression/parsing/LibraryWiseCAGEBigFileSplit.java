package f5expression.parsing;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class LibraryWiseCAGEBigFileSplit {

	
	String fnmAllCAGE;
	String foldOut;
	
	
	/*
	 *  CAGEID | ExprValue in Vector
	 */
	LinkedHashMap<String, Vector<Double>> lhm_cageID_expr = new LinkedHashMap<String, Vector<Double>>();
	/*
	 *  CAGEID | ExprValue index_0based in vector
	 */
	LinkedHashMap<String, Integer> lhm_libName_index0based = new LinkedHashMap<String, Integer>();

	
//	prmtrID	CNhs10608	CNhs10610	CNhs10612	CNhs10615	CNhs10616
//	chr10:100007474..100007500,-	0	0	0	0	0	
	private void loadCAGEfromBigFile() {
		
		long startTime = System.currentTimeMillis();
		
		
		System.out.println("Extracting CAGE info ... ... ... ");
		String strLine = null;
		String tmp[], cageSplit[];

		String cageID;
		String curLibID;


		int index = 0;
		int start_Exp_0based=1;

		Vector<Double> curExpVect ;
		int totDataPoint;
		try {
			
			Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAllCAGE);
			strLine = vectAll.get(0);
			tmp = ConstantValue.patTabSingle.split(strLine);
			totDataPoint=tmp.length-1;
			System.out.println("Total library the file:" + totDataPoint);
			for(int i=1; i<tmp.length;i++)
			{
				curLibID = tmp[i];
				lhm_libName_index0based.put( curLibID, (i-1));
				
			}
			
			for(int i=1; i<vectAll.size();i++){
				strLine = vectAll.get(i);
				tmp = ConstantValue.patTabSingle.split(strLine);
				totDataPoint=tmp.length-1;
//				System.out.println("Total cage entry in each line:" + totDataPoint);
				
				// handling ID
				cageID = tmp[0];
				// handle the Expression values

				curExpVect = new Vector<Double>();
				for(int v=start_Exp_0based; v<tmp.length;v++)
				{
					curExpVect.add(Double.parseDouble(tmp[v])) ;
				}

				lhm_cageID_expr.put(cageID, curExpVect);

				index++;

			}


			System.out.println("Total CAGE cluster in the file:" + index); 

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		
		long endTime   = System.currentTimeMillis();
		long totalTime = ((endTime - startTime)/((long)1000.0) );
		System.out.println("Total time to load the big file: " + totalTime + " sec" );
		
	}

	
	void splitBasedOnLibrary()
	{
		
		String fout;
		StringBuffer buf;
	
		
		/*
		 *  Iterate over each libraryName
		 */
		Set set = lhm_libName_index0based.entrySet();
        System.out.println("Total Unique library:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            String libID = (String)me.getKey();
            Integer indexLibrary0based = (Integer) me.getValue();
            fout = this.foldOut + libID + ".txt";
            buf = new StringBuffer();
           

            /*
             *  Now load the value of all CAGE ID in a library
             */
            
            Set setCAGEid = lhm_cageID_expr.entrySet();
            Iterator itrCAGEid = setCAGEid.iterator();
            while(itrCAGEid.hasNext()){

            	 Map.Entry mapCAGEid = (Map.Entry) itrCAGEid.next();
                 String cageID = (String)mapCAGEid.getKey();
                 Vector<Double> exprVect = (Vector<Double>) mapCAGEid.getValue();
            
                 
                 buf.append(cageID + "\t" + exprVect.get(indexLibrary0based) + "\n");
                 
            }
            
            // write result of 1 library
            CommonFunction.writeContentToFile(fout, buf+"");
        }// iterate over each library
		
		
	}
	

	public LibraryWiseCAGEBigFileSplit(String fnmAllCAGE , String foldOut) {
		super();
		this.fnmAllCAGE = fnmAllCAGE;
		this.foldOut = foldOut;
	}


	
	

	public LinkedHashMap<String, Vector<Double>> getLhm_cageID_expr() {
		return lhm_cageID_expr;
	}



	public void setLhm_cageID_expr(
			LinkedHashMap<String, Vector<Double>> lhm_cageID_expr) {
		this.lhm_cageID_expr = lhm_cageID_expr;
	}



	public LinkedHashMap<String, Integer> getLhm_libName_index0based() {
		return lhm_libName_index0based;
	}



	public void setLhm_libName_index0based(
			LinkedHashMap<String, Integer> lhm_libName_index0based) {
		this.lhm_libName_index0based = lhm_libName_index0based;
	}


	void createSplitDirectory()
	{
		FolderOperations.create_new_folder(this.foldOut);
	}
	

	public static void main(String[] args) {
		LibraryWiseCAGEBigFileSplit obj = new LibraryWiseCAGEBigFileSplit(args[0], args[1]);
		
//		LibraryWiseCAGEBigFileSplit obj = new LibraryWiseCAGEBigFileSplit("/run/media/tanviralam/Data/research/F5lncRNA/TestRIKEN/exprTest.txt", 
//		"/run/media/tanviralam/Data/research/F5lncRNA/TestRIKEN/Split/" );
//		
		obj.createSplitDirectory();
		
		obj.loadCAGEfromBigFile();
		obj.splitBasedOnLibrary();
		
		
	}
	
	
}
