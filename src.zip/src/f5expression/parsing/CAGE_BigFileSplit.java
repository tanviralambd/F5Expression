package f5expression.parsing;





import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class CAGE_BigFileSplit {


	String fnmAllCAGE;
	String foldOut;


	Vector<String> vectAll ;
	/*
	 *  For file: hg19.cage_peak_phase1and2combined_tpm_ann.osc.txt
	 */
	int indexHeaderLine=1831, indexMappedLine=1832,indexNormFactorLine=1833, indexExprStartLine=1834;
	int start_ExpColumn_0based=1;
	int totDataPoint;
	/*
	 *  CAGEID | ExprValue in Vector
	 */
	LinkedHashMap<String, Vector<Double>> lhm_cageID_expr = new LinkedHashMap<String, Vector<Double>>();


	/*
	 *  CAGEID | Gene Name
	 */
	//	LinkedHashMap<String, String> lhm_cageID_Gene = new LinkedHashMap<String, String >();



	/*
	 *  CAGEID | ExprValue index_0based in vector
	 */
	LinkedHashMap<String, Integer> lhm_libName_index0based = new LinkedHashMap<String, Integer>();


	//	prmtrID	CNhs10608	CNhs10610	CNhs10612	CNhs10615	CNhs10616
	//	chr10:100007474..100007500,-	0	0	0	0	0	
	private void loadCAGEfromBigFile() {

		long startTime = System.currentTimeMillis();


		System.out.println("Extracting CAGE info ... ... ... ");
		String strLine = null;
		String tmp[], cageSplit[];

		String cageID;
		String curLibID;


		int index = 0;
		int start_Exp_0based=1;

		Vector<Double> curExpVect ;
		int totDataPoint;
		try {

			Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAllCAGE);
			strLine = vectAll.get(0);
			tmp = ConstantValue.patTabSingle.split(strLine);
			totDataPoint=tmp.length-1;
			System.out.println("Total library the file:" + totDataPoint);
			for(int i=1; i<tmp.length;i++)
			{
				curLibID = tmp[i];
				lhm_libName_index0based.put( curLibID, (i-1));

			}

			for(int i=1; i<vectAll.size();i++){
				strLine = vectAll.get(i);
				tmp = ConstantValue.patTabSingle.split(strLine);
				totDataPoint=tmp.length-1;
				//				System.out.println("Total cage entry in each line:" + totDataPoint);

				// handling ID
				cageID = tmp[0];
				// handle the Expression values

				curExpVect = new Vector<Double>();
				for(int v=start_Exp_0based; v<tmp.length;v++)
				{
					curExpVect.add(Double.parseDouble(tmp[v])) ;
				}

				lhm_cageID_expr.put(cageID, curExpVect);

				index++;

			}


			System.out.println("Total CAGE cluster in the file:" + index); 

		} catch (Exception e) {
			e.printStackTrace();
		}



		long endTime   = System.currentTimeMillis();
		long totalTime = ((endTime - startTime)/((long)1000.0) );
		System.out.println("Total time to load the big file: " + totalTime + " sec" );

	}


	private void loadCAGEFile() {


		System.out.println("Extracting CAGE info ... ... ... ");
		String strLine = null;
		String tmp[], cageSplit[];

		String cageID; // , uniprotID;

		Vector<Double> curExpVect ;
		int  index=0;
		int startExprValue;
		try {

			for(int i= indexExprStartLine; i<vectAll.size();i++){
				strLine = vectAll.get(i);

				tmp = ConstantValue.patTab.split(strLine);

				if( (tmp.length - start_ExpColumn_0based ) < this.totDataPoint )
				{
					System.out.println( "Some columns are missing" );
//					uniprotID = ConstantValue.noneStr ; 
					startExprValue = tmp.length - this.totDataPoint  ;
				}else
				{
					startExprValue = start_ExpColumn_0based;
//					uniprotID = tmp[6];
				}


				// handling ID
				cageID = tmp[0];
				//				lhm_cageID_Gene.put(cageID, uniprotID);

				//



				// handle the Expression values

				curExpVect = new Vector<Double>();
				for(int v=  startExprValue ; v<tmp.length;v++)
				{
					curExpVect.add(Double.parseDouble(tmp[v])) ;
				}

				lhm_cageID_expr.put(cageID, curExpVect);

				System.out.println( cageID + "  has   " +    curExpVect.size()  + "  expression value");

				index++;


			}

			System.out.println("Total CAGE cluster in the file:" + index); 

		} catch (Exception e) {
			e.printStackTrace();
		}





	}


	void splitBasedOnLibrary()
	{

		String cageID="";

		try {

			String fout;
			StringBuffer buf ;
			//		, uniprotbuf;

			String tmpCSV[];
			/*
			 *  Iterate over each libraryName
			 */
			Set set = lhm_libName_index0based.entrySet();
			System.out.println("Total Unique library:" + set.size() ) ;
			Iterator itr = set.iterator();
			while(itr.hasNext()){


				Map.Entry me = (Map.Entry) itr.next();
				String libID = (String)me.getKey();
				Integer indexLibrary0based = (Integer) me.getValue();
				fout = this.foldOut + libID + ".txt";
				buf = new StringBuffer();


				/*
				 *  Now load the value of all CAGE ID in a library
				 */

				Set setCAGEid = lhm_cageID_expr.entrySet();
				Iterator itrCAGEid = setCAGEid.iterator();
				while(itrCAGEid.hasNext()){

					Map.Entry mapCAGEid = (Map.Entry) itrCAGEid.next();
					cageID = (String)mapCAGEid.getKey();
					Vector<Double> exprVect = (Vector<Double>) mapCAGEid.getValue();

					//				tmpCSV = ConstantValue.patCSV.split( lhm_cageID_Gene.get(cageID)  );
					//				uniprotbuf = new StringBuffer();
					//				for( int k=0 ; k<tmpCSV.length ;k++)
					//				{
					//					uniprotbuf.append( tmpCSV[ k].substring( tmpCSV[k].indexOf(':') +1  ) + ConstantValue.seperatorList   ) ;
					//				}


					//				System.out.println( "Writing for : " + cageID );
					buf.append(cageID   + "\t" + exprVect.get(indexLibrary0based)   + "\n");

				}

				// write result of 1 library
				CommonFunction.writeContentToFile(fout, buf+"");
			}// iterate over each library


		} catch (Exception e) {
			System.out.println("Error for " + cageID );
			e.printStackTrace();
		}

	}


	public CAGE_BigFileSplit(String fnmAllCAGE , String foldOut) {
		super();
		this.fnmAllCAGE = fnmAllCAGE;
		this.foldOut = foldOut;
	}





	public LinkedHashMap<String, Vector<Double>> getLhm_cageID_expr() {
		return lhm_cageID_expr;
	}



	public void setLhm_cageID_expr(
			LinkedHashMap<String, Vector<Double>> lhm_cageID_expr) {
		this.lhm_cageID_expr = lhm_cageID_expr;
	}



	public LinkedHashMap<String, Integer> getLhm_libName_index0based() {
		return lhm_libName_index0based;
	}



	public void setLhm_libName_index0based(
			LinkedHashMap<String, Integer> lhm_libName_index0based) {
		this.lhm_libName_index0based = lhm_libName_index0based;
	}


	void createSplitDirectory()
	{
		FolderOperations.create_new_folder(this.foldOut);
	}


	String getLibIDFromFullName(String fullID)
	{
		String finalID;
		int ind = fullID.indexOf(".CNhs");
		String sub = fullID.substring(ind+1);

		int indexDot = sub.indexOf('.');
		finalID = sub.substring( 0 , indexDot);


		return finalID;
	}

	void loadSampleName()
	{

		System.out.println("Extracting CAGE info ... ... ... ");
		String strLine = null;
		String tmp[];


		String fullID, curLibID;

		strLine = vectAll.get(indexHeaderLine);
		tmp = ConstantValue.patTabSingle.split(strLine);
		totDataPoint=tmp.length - start_ExpColumn_0based;
		System.out.println("Total library the file:" + totDataPoint);


		for(int i=start_ExpColumn_0based; i< tmp.length;i++)
		{
			fullID = tmp[i];
			curLibID = getLibIDFromFullName(fullID);
			lhm_libName_index0based.put( curLibID, (i - start_ExpColumn_0based ));

//			System.out.println( curLibID );
		}
	}

	void readBigFile()
	{
		this.vectAll = CommonFunction.readlinesOfAfile(this.fnmAllCAGE);
	}


	void doProcessing()
	{

		long startTime = System.currentTimeMillis();


		createSplitDirectory();
		readBigFile();
		loadSampleName();
		loadCAGEFile();
		splitBasedOnLibrary();


		long endTime   = System.currentTimeMillis();
		long totalTime = ((endTime - startTime)/((long)1000.0) );
		System.out.println("Total time to load the big file: " + totalTime + " sec" );

	}

	public static void main(String[] args) {
		CAGE_BigFileSplit obj = new CAGE_BigFileSplit(args[0], args[1]);

//						CAGE_BigFileSplit obj = new CAGE_BigFileSplit(
//								"hg19.cage_peak_phase1and2combined_tpm.osc.txt.header", 
//								"./splitPublic/" );

		obj.doProcessing();


	}


}

