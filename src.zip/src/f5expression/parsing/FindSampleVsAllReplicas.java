package f5expression.parsing;

import java.security.CryptoPrimitive;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class FindSampleVsAllReplicas {



	String fnmInput;
	String fnmOutput;


	class Samples{


		String name;
		String type;
		Vector<String> vectID = new Vector<String>();
		Vector<String> vectDetails = new Vector<String>();

		public Samples() {
			super();
		}


		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}


		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}


		public Vector<String> getVectID() {
			return vectID;
		}
		public void setVectID(Vector<String> vectID) {
			this.vectID = vectID;
		}



		public Vector<String> getVectDetails() {
			return vectDetails;
		}

		public void setVectDetails(Vector<String> vectDetails) {
			this.vectDetails = vectDetails;
		}


		public String getAllID()
		{

			StringBuffer buf = new StringBuffer();
			String result="";
			for(int i=0 ;  i<vectID.size();i++)
			{
				if( i == vectID.size() -1 )
				{
					buf.append(vectID.get(i));
				}else
				{
					buf.append(vectID.get(i) + "#");
				}

			}

			return buf+"";
		}



		public String getAllDescription()
		{


			StringBuffer buf = new StringBuffer();
			String result="";
			for(int i=0 ;  i<vectDetails.size();i++)
			{
				if( i == vectDetails.size() -1 )
				{
					buf.append(vectDetails.get(i));
				}else
				{
					buf.append(vectDetails.get(i) + "#");
				}

			}

			return buf+"";
		}



	}



	//	LinkedHashMap<String, String> lhm_name_Details = new LinkedHashMap<String, String>();
	LinkedHashMap<String, Samples> lhm_name_Details = new LinkedHashMap<String, Samples>();



	void doProcessing()
	{

		loadFileInfo();
		writeSummary();

	}






	void loadFileInfo()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);


		String tmp[] , tmpCSV[];
		String tissueName,curDetails, prevDetails , curID , curType;
		String withoutSpace ,withoutBracket , replaceNonAlpha;

		int index_ID=2, index_type=7 , index_Detaiils=8 ;

		int totTissue=0, totPrimaryCell=0;

		for( int i=0 ;  i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i ) );

			curID = tmp[index_ID];
			curDetails = tmp[index_Detaiils];
			curType = tmp[index_type];





			if( curDetails.contains("control"))
			{
				continue;
			}


			//			if( curType.equals("tissue") || curType.equals("primary_cell"))
			{
				tmpCSV = ConstantValue.patCSV.split( curDetails );



				withoutSpace = CommonFunction.replaceSpaceHyphenQuoteByChar( tmpCSV[0] , "_");
				withoutBracket =  withoutSpace.replaceAll( ConstantValue.patBracket.toString() , "");
				//				replaceNonAlpha   =  withoutBracket.replaceAll( ConstantValue.patNOTAlphaNumeric.toString() , "_");



				//				tissueName =  tmpCSV[0].toUpperCase()  ;
				//				tissueName = CommonFunction.replaceSpaceHyphenByChar( tmpCSV[0].toUpperCase()  , "_" ).toUpperCase() ;
				tissueName = withoutBracket.toUpperCase();
				//								tissueName = replaceNonAlpha.toUpperCase();



				if(lhm_name_Details.containsKey(tissueName))
				{
					System.out.println( tissueName + "  :already exist");


					lhm_name_Details.get(tissueName).getVectID().add(curID );
					lhm_name_Details.get(tissueName).getVectDetails().add(curDetails );



				}else
				{
					Samples curSample = new Samples();
					curSample.setName(tissueName);
					curSample.setType(curType);
					curSample.getVectID().add(curID );
					curSample.getVectDetails().add(curDetails);


					lhm_name_Details.put( tissueName,  curSample );
				}

			}



		}


		System.out.println(  "Total entry : " + lhm_name_Details.size() );




	}

	void writeSummary()
	{
		StringBuffer buf = new StringBuffer();

		String curType="";
		int totPrimaryCell=0,totTissue=0;

		Set set = lhm_name_Details.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String id = (String)me.getKey();
			Samples curSam = (Samples) me.getValue();
			curType = curSam.getType();
			buf.append(id  + "\t" + curType  + "\t" + curSam.getAllID() + "\t" + curSam.getAllDescription() + "\n" ) ;

			//            String details = (String) me.getValue();
			//            buf.append(id  + "\t"  + details + "\n" ) ;

			if( curType.equals("tissue"))
			{
				totTissue++;
			}else if( curType.equalsIgnoreCase("primary_cell"))
			{
				totPrimaryCell++;
			}


		}

		CommonFunction.writeContentToFile(this.fnmOutput, buf + "" );

		System.out.println(  "Total primary_cell : " +  totPrimaryCell );
		System.out.println(  "Total tissue : " + totTissue );

	}

	public FindSampleVsAllReplicas(String fnmInput, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOutput = fnmOutput;
	}




	public static void main(String[] args) {

		FindSampleVsAllReplicas obj = new FindSampleVsAllReplicas( args[0] , args[1]);

//				FindSampleVsAllReplicas obj = new FindSampleVsAllReplicas( "final.CAGE.sample_info.FANTOM.xlsx.txt", "final.CAGE.sample_info.FANTOM.xlsx.txt.tsv");

		//		FindSampleVsAllReplicas obj = new FindSampleVsAllReplicas( "testTissue.txt" ,"testTissue.txt.out");

		//		FindSampleVsAllReplicas obj = new FindSampleVsAllReplicas( "testPrimaryCell.txt" ,"testPrimaryCell.txt.out");

		obj.doProcessing();

		//		promyelocytes/myelocytes PMC, donor2


		//		FindSampleVsAllReplicas obj1 = new FindSampleVsAllReplicas( args[0] , args[1]);

		//				String input="(AB   C  D)[]{}() promyelocytes/-myelocytes PMC";
		//				String withoutSpace = CommonFunction.replaceSpaceHyphenByChar( input , "_");
		//				String withoutBracket =  withoutSpace.replaceAll( ConstantValue.patBracket.toString() , "");
		//				String replaceNonAlpha   =  withoutBracket.replaceAll( ConstantValue.patNOTAlphaNumeric.toString() , "_");
		//				
		//				
		//				
		//				System.out.println( withoutSpace);
		//				System.out.println(  withoutBracket ) ;
		//				System.out.println(  replaceNonAlpha ) ;
		//				
		//				System.out.println(  withoutBracket.replaceAll(  ConstantValue.patNOTAlphaNumeric.toString()  , "_")  )  ;
	}

}
