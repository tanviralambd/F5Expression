package f5expression.parsing;

import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class LibraryNameGenerate {

	
	String fnmSampleInfo;
	String type;
	String fnmout;
	
	
	void doProcessing()
	{
		Vector<String>  vectString = CommonFunction.readlinesOfAfile(this.fnmSampleInfo);
		StringBuffer resBuf = new StringBuffer();
		String tmp[];
		
		String F5_CAGE_Lib_ID;
		String F5_Sample_Type;

		
		for(int i=1; i<vectString.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectString.get(i));
			
			F5_CAGE_Lib_ID = tmp[2];
			F5_Sample_Type = tmp[7];
			
			
			if(F5_Sample_Type.equals(this.type))
			{
//				resBuf.append(F5_CAGE_Lib_ID + "\n");
				
				resBuf.append(F5_CAGE_Lib_ID + "\t" + F5_Sample_Type  +"\n");
			}
			
		}
		
		
		
		
		CommonFunction.writeContentToFile(this.fnmout, resBuf+"" );
	}
	
	
	
	public LibraryNameGenerate(String fnmSampleInfo, String type, String fnmout) {
		super();
		this.fnmSampleInfo = fnmSampleInfo;
		this.type = type;
		this.fnmout = fnmout;
	}



	public static void main(String[] args) {
		
		// cell_line  primary_cell  timecourse  tissue

		
		LibraryNameGenerate obj = new LibraryNameGenerate(args[0], args[1] , args[2]);

//		LibraryNameGenerate obj = new LibraryNameGenerate("/run/media/tanviralam/Data/research/F5lncRNA/TestRIKEN/dataCoexpr/FANTOM5_CAGE_sample_info_20150515.tsv", 
//				"primary_cell" , 
//				"/run/media/tanviralam/Data/research/F5lncRNA/TestRIKEN/dataCoexpr/FANTOM5_CAGE_sample_info_20150515.tsv.primary_cell");
		
		
		
		obj.doProcessing();
		
	}
	
	
}
