package f5expression.bean;

import java.util.Comparator;

public class BedFormat implements Comparable<BedFormat>{

	// MANDATORY FIELDS
	String chrom;
    int start;
    int end;
    String name;
    String score;
    char strand;
    
    // OPTIONAL FIELDS
    int cdsStart;
    int cdsEnd;
    
    
    
    // FOR CALCULATION
    int indexSeq_0_Based;
    int tss;
    int tis;




	int midPoint;
    
	public int compareTo(BedFormat obj) {
       
        return (this.start > obj.start ) ? 1  :  -1 ;
    }
    
    
	public BedFormat(String chrom, int start, int end, String name,
			String score, char strand) {
		super();
		this.chrom = chrom;
		this.start = start;
		this.end = end;
		this.name = name;
		this.score = score;
		this.strand = strand;

		if(this.strand=='+')
		{
			this.tss = this.start;
		}else
		{
			this.tss = this.end-1;
		}
		this.midPoint = (this.start+this.end)/2;
	}
	
	public BedFormat(String chrom, int start, int end, String name,
			String score, char strand , int CDSstart , int CDSend) {
		super();
		this.chrom = chrom;
		this.start = start;
		this.end = end;
		this.name = name;
		this.score = score;
		this.strand = strand;

		if(this.strand=='+')
		{
			this.tss = this.start;
		}else
		{
			this.tss = this.end-1;
		}
		this.midPoint = (this.start+this.end)/2;
		
		
		
		this.cdsStart = CDSstart;
		this.cdsEnd = CDSend;
		if(this.strand=='+')
		{
			this.tis = this.cdsStart;
		}else
		{
			this.tis = this.cdsEnd-1;
		}
		
		
		
	}
	
	
	
	


	public BedFormat(String chrom, int start, int end, String name, String score, char strand, int ind) {
		super();
		this.chrom = chrom;
		this.start = start;
		this.end = end;
		this.name = name;
		this.score = score;
		this.strand = strand;
		this.indexSeq_0_Based = ind;
		
		if(this.strand=='+')
		{
			this.tss = this.start;
		}else
		{
			this.tss = this.end-1;
		}
		this.midPoint = (this.start+this.end)/2;
	}
	
	public BedFormat(String chrom, String start, String end, String name, String score, String strn, int ind) {
		super();
		this.chrom = chrom;
		this.start = Integer.parseInt( start );
		this.end = Integer.parseInt( end );
		this.name = name;
		this.score = score;
		this.strand = strn.charAt(0);
		this.indexSeq_0_Based =  ind;
		
		if(this.strand=='+')
		{
			this.tss = this.start;
		}else
		{
			this.tss = this.end-1;
		}
		this.midPoint = (this.start+this.end)/2;
	}
	
	
	public int getIndexSeq_0_Based() {
		return indexSeq_0_Based;
	}

	public void setIndexSeq_0_Based(int indexSeq_0_Based) {
		this.indexSeq_0_Based = indexSeq_0_Based;
	}

	public String getChrom() {
		return chrom;
	}
	public void setChrom(String chrom) {
		this.chrom = chrom;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public char getStrand() {
		return strand;
	}
	public void setStrand(char strand) {
		this.strand = strand;
	}
    public int getTss() {
		return tss;
	}


	public void setTss(int tss) {
		this.tss = tss;
	}
	
	
    public int getTis() {
		return tis;
	}


	public void setTis(int tis) {
		this.tis = tis;
	}
	
	public int getMidPoint() {
		return midPoint;
	}


	public void setMidPoint(int midPoint) {
		this.midPoint = midPoint;
	}
	
	
	public int getCdsStart() {
		return cdsStart;
	}


	public void setCdsStart(int cdsStart) {
		this.cdsStart = cdsStart;
	}


	public int getCdsEnd() {
		return cdsEnd;
	}


	public void setCdsEnd(int cdsEnd) {
		this.cdsEnd = cdsEnd;
	}

	
	
	public String toStringTSS_6fields()
	{
		String result;
		result= this.chrom + "\t" + this.tss + "\t"  + (this.tss+1) + "\t"  + this.name + "\t"  + this.score + "\t"  + this.strand;
		return result;
	}
	
    
	
}
