package f5expression.bean;

import java.util.ArrayList;

public class RMSK {

	String  rmskChrom;
	Integer rmskStart;
    Integer rmskEnd;
    
   
    String rmskClass;
    
    
    
    
	public RMSK(String rptChrm, Integer rptStart, Integer rptEnd,
			  String rptClass) {
		super();
		this.rmskChrom = rptChrm;
		this.rmskStart = rptStart;
		this.rmskEnd = rptEnd;
		
		
		this.rmskClass = rptClass;
	}




	public String getRmskChrom() {
		return rmskChrom;
	}




	public void setRmskChrom(String rmskChrom) {
		this.rmskChrom = rmskChrom;
	}




	public Integer getRmskStart() {
		return rmskStart;
	}




	public void setRmskStart(Integer rmskStart) {
		this.rmskStart = rmskStart;
	}




	public Integer getRmskEnd() {
		return rmskEnd;
	}




	public void setRmskEnd(Integer rmskEnd) {
		this.rmskEnd = rmskEnd;
	}





	public String getRmskClass() {
		return rmskClass;
	}




	public void setRmskClass(String rmskClass) {
		this.rmskClass = rmskClass;
	}
	
	
	
    
    
    
}
