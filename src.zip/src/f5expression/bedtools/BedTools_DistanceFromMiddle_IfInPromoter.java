package f5expression.bedtools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Pattern;

import f5expression.bean.BedFormat;
import f5expression.bean.RMSK;
import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class BedTools_DistanceFromMiddle_IfInPromoter {


	String fnmOne;
	String fnmTwo;
	String fnmOut;

	String foldIn1;
	String foldIn2;

	String foldOut;

	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState = new HashMap<String, Vector<BedFormat>>();
	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState2 = new HashMap<String, Vector<BedFormat>>();


	public void init(String foldIn1, String foldIn2, String foldOut, String fnm1, String fnm2, String fnmOut)
	{
		this.foldIn1 = foldIn1;
		this.foldIn2 = foldIn2;
		this.foldOut = foldOut;
		this.fnmOne = this.foldIn1 + "/" + fnm1;
		this.fnmTwo =  this.foldIn2 + "/" +  fnm2;

		this.fnmOut =  this.foldOut + "/" + fnmOut;		

	}


	void makeChrmWisePromoterMap() {
		System.out.println("Extracting prom info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[,\\t]+");
		int index = 0;

		try {

			FileInputStream fstream = new FileInputStream(fnmOne);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));


			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);

				try {
					addInChrMap( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total PROMOTER entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();
			//            out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}





	void addInChrMap( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState.containsKey(chrm)) {
			mapChrmWisePromoterState.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState.put(chrm, vp);
		}

	}


	void addInChrMap2( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState2.containsKey(chrm)) {
			mapChrmWisePromoterState2.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState2.put(chrm, vp);
		}

	}


	void makeChrmWisePromoterMap2() {
		System.out.println("Extracting peak info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[,\\t]+");
		int index = 0;
		try {

			FileInputStream fstream = new FileInputStream(fnmTwo);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);

				try {

					addInChrMap2 ( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total PEAK entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void findDistance()
	{
		int minDist = Integer.MAX_VALUE;
		int disMidPoint=0;
		String other=null;
		try {
			BufferedWriter bwr = new BufferedWriter(new FileWriter( this.fnmOut));
			StringBuffer buf = new StringBuffer();

			Set setChrm = mapChrmWisePromoterState.entrySet();
			Set setChrm2 = mapChrmWisePromoterState2.entrySet();


			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				String currentChrm = (String)me.getKey();
				//				System.out.println("Find overlap in chromosome:"+ currentChrm);

				Vector<BedFormat> vp = (Vector<BedFormat>) me.getValue();
				Vector<BedFormat> vp2 =  mapChrmWisePromoterState2.get(currentChrm);
				if(vp2==null)
					System.out.println("No peak found for chromosome: "+ currentChrm) ;
				for(int i=0;  i<vp.size() ;i++)
				{
					if(vp2 != null)
					{
						minDist = Integer.MAX_VALUE;

						for(int j=0; j<vp2.size();j++)
						{

							// if this peakregion is in promoter, then Genomic distance <= 2000
							if( CommonFunction.getGenomicDist(vp.get(i).getStart(), vp.get(i).getEnd() ,vp2.get(j).getStart() ,vp2.get(j).getEnd() ) <= ConstantValue.SEQLEN)
							{
								disMidPoint = Math.abs( (   ( vp.get(i).getStart() + vp.get(i).getEnd()  )   -  (  vp2.get(j).getStart()  + vp2.get(j).getEnd() )  )/2   )   ;
								if(disMidPoint < minDist)
								{
									minDist = disMidPoint ;
									other =  vp2.get(j).getChrom()+"\t" +  vp2.get(j).getStart() + "\t" + vp2.get(j).getEnd() + "\t" + vp2.get(j).getStrand() ;
								}

							}
						}

						if(minDist != Integer.MAX_VALUE) // no chipSeqPeak in promoter is found
						{
							buf.append((  vp.get(i).getChrom()+"\t" +  vp.get(i).getStart() + "\t" + vp.get(i).getEnd() + "\t" +vp.get(i).getStrand() + "\t" +
									other + "\t" + minDist +  "\n" ) );
						}






					}

				}

			}

			bwr.write(buf+"");

			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}




	}

	void doProcessing()
	{
		makeChrmWisePromoterMap();
		makeChrmWisePromoterMap2();

		findDistance();


	}

	public static void main(String[] args) {

		BedTools_DistanceFromMiddle_IfInPromoter obj = new BedTools_DistanceFromMiddle_IfInPromoter();

		//		obj.init("media/Data/eclipseWorkspace/CNCfinalversion/","media/Data/eclipseWorkspace/CNCfinalversion/",  "testa.bed",  "testb.bed" ,  "check.bed" );
		obj.init(args[0], args[1], args[2], args[3], args[4] , args[5]);

		obj.doProcessing();




	}


}
