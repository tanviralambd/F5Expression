package f5expression.bedtools;

import java.util.Vector;
import java.util.regex.Pattern;

import f5expression.bean.BedFormat;
import f5expression.common.CommonFunction;

public class Bedtools_BedToTSS {

	
	void convert_Bed_To_TSS(String fnmBed, String fnmBedExons)
	{
		
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		BedFormat myBed;
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i));
			myBed = new BedFormat(tmp[0], tmp[1], tmp[2], tmp[3] , tmp[4 ], tmp[5] , i);

			buf.append(myBed.toStringTSS_6fields() +"\n");
			
		}
	
		CommonFunction.writeContentToFile(fnmBedExons, buf+"");
		
	}
	

	
	
	public static void main(String[] args) {
		Bedtools_BedToTSS obj = new Bedtools_BedToTSS();
		obj.convert_Bed_To_TSS(args[0],   args[1] ); 

		
	}
}

