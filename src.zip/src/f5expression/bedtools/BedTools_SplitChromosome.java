package f5expression.bedtools;

import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class BedTools_SplitChromosome {

	
	String finBed;
	String foutFolder;
	String foutExt;
	
	
	
	
	


	public BedTools_SplitChromosome(String finBed, String foutFolder,
			String foutExt) {
		super();
		this.finBed = finBed;
		this.foutFolder = foutFolder;
		this.foutExt = foutExt;
	}

	StringBuffer buf[] = new StringBuffer [ ConstantValue.human_total_Chromosome];
	
	
		
	void initBuffer()
	{
		for(int i=0; i<ConstantValue.human_total_Chromosome;i++)
		{
			this.buf[i] = new StringBuffer();
			
		}
	}
	
	void insertIntoAppropriateBuffer(String chr, String desc)
	{
		
		int index= CommonFunction.getIndexFromChromosome(chr);
		if(index!=-1){
			this.buf[index].append(desc + "\n");
		}else
		{
			System.out.println("Unknown chromosome");
		}
	}
	
	
	void writeSeperateChromosome()
	{
		
		for(int i=0; i<buf.length;i++)
		{
			StringBuffer curBuffer = buf[i];
			
			
			CommonFunction.writeContentToFile( this.foutFolder+CommonFunction.getChromosomeFromIndex(i) + this.foutExt  , curBuffer + "");
			
		}
		
		
	}
	
	void doProcessing()
	{
		
		initBuffer();
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.finBed);
		String curLine;
		String tmp[];
		String chr;
		for(int i=0; i<vectAll.size();i++)
		{
			
			curLine = vectAll.get(i ) ;
			tmp = ConstantValue.patTab.split(curLine);
			
			chr = tmp[0];
			
			insertIntoAppropriateBuffer(chr, curLine);
			
		}
		
		writeSeperateChromosome();
	}
	
	public static void main(String[] args) {
	
		BedTools_SplitChromosome obj = new BedTools_SplitChromosome(args[0], args[1] , args[2]);
		
//		BedTools_SplitChromosome obj = new BedTools_SplitChromosome("/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/test.bed", 
//				"/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/",
//		".intron.bed");
		
		obj.doProcessing();
		
		
	}
	
	
	
}
