package f5expression.bedtools;

import java.util.Vector;
import java.util.regex.Pattern;

import f5expression.bean.TrxExonInfo;
import f5expression.common.CommonFunction;

public class BedTools_CodingTranscript_CDS {

	
	
	void load_Bed_CDS(String fnmBed, String fnmBedExons)
	{
		
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		int dist_TSS_TIS ;
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i), 12);
			TrxExonInfo trx = new TrxExonInfo(tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7], tmp[8], tmp[9], tmp[10], tmp[11]) ;
			
			// create 1 entry for transcript
			
			buf.append(  trx.toCDS_BED() + "\n");
			// create multiple entry for exons
			
		}
	
			
	
		CommonFunction.writeContentToFile(fnmBedExons, buf+"");
		
	}
	

	
	
	public static void main(String[] args) {
		BedTools_CodingTranscript_CDS  obj = new BedTools_CodingTranscript_CDS();
		
//		obj.load_Bed_CDS(args[0],   args[1] ); 
		// example
//		obj.load_Bed_CDS_Exons("./test.bed",    "./test.bed.dist" ); 
//		obj.load_Bed_CDS("./refseqcoding.bed",    "./refseqcoding.CDS.bed" );
		obj.load_Bed_CDS("./refseq2014.bed",    "./refseq2014.CDS.bed" );
	}
	
	
}
