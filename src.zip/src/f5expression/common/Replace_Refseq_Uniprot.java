package f5expression.common;

import java.util.LinkedHashMap;
import java.util.Vector;

import f5expression.constant.ConstantValue;

public class Replace_Refseq_Uniprot {

	
	String fnm_Refseq_Uniprot;
	
	String fnmInput;
	int index_0_Refseq;
	
	String fnmOutput;
	
	
	/*
	 *  Global variables
	 */
	
	LinkedHashMap<String, String >  lhm_Refseq_Uniprot = new LinkedHashMap<String, String>();
	
	
	void loadRepository_Refseq_Uniprot()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnm_Refseq_Uniprot);
		String tmp[];
		StringBuffer bufRes = new StringBuffer();
		int totColumn;
		String ref, unip , columnVal;
		for( int i=0 ; i<vectAll.size() ;i++)
		{
			
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			ref = tmp[0];
			unip = tmp[1];
			
			lhm_Refseq_Uniprot.put(ref, unip);
			
			
		}
		
		System.out.println(" Total Line in Repository: " + vectAll.size() + "  Total Uniq Refseq: " + lhm_Refseq_Uniprot.size() );
		
		
	}
	
	
	void replace_Refseq_byUniprot()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		StringBuffer bufRes  = new StringBuffer();
		
		String tmp[];
		int totColumn;
		String ref, unip, columnVal;
		for( int i=0 ; i<vectAll.size() ;i++)
		{
			
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			totColumn = tmp.length;
			
			ref = tmp[ this.index_0_Refseq];
			
			if( lhm_Refseq_Uniprot.containsKey(ref))
			{
				unip =  lhm_Refseq_Uniprot.get(ref);
			}else
			{
				
				continue; // If not found in repository, no need to work on it
			}
			
			
			
			for( int k=0 ;  k< totColumn ;k++)
			{
				if( k == this.index_0_Refseq)
				{
					columnVal  =   unip ;
				}else
				{
					columnVal = tmp[k] ;
				}
				
				if( k== totColumn-1)
				{
					bufRes.append(  columnVal + "\n" );
				}else
				{
					bufRes.append(  columnVal + "\t" );
				}
			}
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOutput, bufRes + "" );
		
		
		
	}
	
	
	void doProcessing()
	{
		
		loadRepository_Refseq_Uniprot();
		
		
		replace_Refseq_byUniprot();
		
		
		
	}
	
	
	
	
	
	public Replace_Refseq_Uniprot(String fnm_Refseq_Uniprot, String fnmInput,
			int index_0_Refseq, String fnmOutput) {
		super();
		this.fnm_Refseq_Uniprot = fnm_Refseq_Uniprot;
		this.fnmInput = fnmInput;
		this.index_0_Refseq = index_0_Refseq;
		this.fnmOutput = fnmOutput;
	}





	public static void main(String[] args) {
		
		Replace_Refseq_Uniprot obj = new Replace_Refseq_Uniprot(args[0], args[1], Integer.parseInt(args[2] ), args[3]);
		
		obj.doProcessing();
		
	}
	
	
}
