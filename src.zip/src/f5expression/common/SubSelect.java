package f5expression.common;

import java.util.LinkedHashMap;
import java.util.Set;

public class SubSelect {

	
	String fName1;
	int index0based1;

	String fName2;
	int index0based2;

	String fNameCommon;




	public SubSelect(String fName1, int index0based1, String fName2,
			int index0based2, String fNameCommon) {
		super();
		this.fName1 = fName1;
		this.index0based1 = index0based1;
		this.fName2 = fName2;
		this.index0based2 = index0based2;
		this.fNameCommon = fNameCommon;
	}


	void doProcessing()
	{

		LinkedHashMap<String, String> lhm_1id = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fName1, this.index0based1);

		LinkedHashMap<String, String> lhm_2Details = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fName2, this.index0based2);


		Set<String> intersectionID = lhm_1id.keySet();
		intersectionID.retainAll(lhm_2Details.keySet());

		System.out.println("common between files: " + intersectionID.size());
		

		StringBuffer buf = new StringBuffer();

		String[] arrID = (String[]) intersectionID.toArray(new String[intersectionID.size()]);
		int setSize = arrID.length;
		for(int c=0; c < setSize;c++)
		{
			
			buf.append(  lhm_2Details.get( arrID[c] ) +"\n");
			
		} 

		CommonFunction.writeContentToFile(this.fNameCommon, buf+"");
	}

	
	
	


	public static void main(String[] args) {


		SubSelect obj = new SubSelect(args[0], Integer.parseInt(args[1])	, args[2], Integer.parseInt(args[3] ), args[4]);
		
		
//		SubSelect obj = new SubSelect("result1.id", Integer.parseInt( "0" )	, "result2.id", Integer.parseInt( "0" ), "common.id"  );
		
		
		obj.doProcessing();
		

	}
	
	
}
