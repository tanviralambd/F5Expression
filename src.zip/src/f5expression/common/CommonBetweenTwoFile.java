package f5expression.common;

import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Vector;

public class CommonBetweenTwoFile {


	String fName1;
	int index0based1;

	String fName2;
	int index0based2;

	String fNameCommon;




	public CommonBetweenTwoFile(String fName1, int index0based1, String fName2,
			int index0based2, String fNameCommon) {
		super();
		this.fName1 = fName1;
		this.index0based1 = index0based1;
		this.fName2 = fName2;
		this.index0based2 = index0based2;
		this.fNameCommon = fNameCommon;
	}


	void doProcessing()
	{

		LinkedHashMap<String, String> lhm_1 = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fName1, this.index0based1);

		LinkedHashMap<String, String> lhm_2 = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fName2, this.index0based2);


		Set<String> intersection = lhm_1.keySet();
		intersection.retainAll(lhm_2.keySet());

		System.out.println("common between files: " + intersection.size());
		

		StringBuffer buf = new StringBuffer();

		String[] arr = (String[]) intersection.toArray(new String[intersection.size()]);
		int setSize = arr.length;
		for(int c=0; c < setSize;c++)
		{
//			if(c==setSize-1)
//				buf.append(arr[c]+"\n");
//			else
//				buf.append(arr[c]+",");

			
			buf.append(arr[c]+"\n");
			
		} 

		CommonFunction.writeContentToFile(this.fNameCommon, buf+"");
	}

	
	
	


	public static void main(String[] args) {


		CommonBetweenTwoFile obj = new CommonBetweenTwoFile(args[0], Integer.parseInt(args[1])	, args[2], Integer.parseInt(args[3] ), args[4]);
		
		
//		CommonBetweenTwoFile obj = new CommonBetweenTwoFile("result1.id", Integer.parseInt( "0" )	, "result2.id", Integer.parseInt( "0" ), "common.id"  );
		
		
		obj.doProcessing();
		

	}


}
