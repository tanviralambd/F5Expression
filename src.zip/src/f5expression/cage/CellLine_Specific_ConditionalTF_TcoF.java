package f5expression.cage;


import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class CellLine_Specific_ConditionalTF_TcoF {


	String foldResultsCAGE;
	String fnmAllTFTExpressed;
	String fnmAllTcoFTExpressed;
	
	String fnmTf_TcoFRepository;


	String fnmOutput;

	
	/*
	 * Global Variables 
	 */
	LinkedHashMap<String, Set <String> > lhm_TF_TcoF = new LinkedHashMap<String, Set<String>>();

	
	


	public CellLine_Specific_ConditionalTF_TcoF(String foldResultsCAGE,
			String fnmAllTFTExpressed, String fnmAllTcoFTExpressed,
			String fnmTf_TcoFRepository, String fnmOutput) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmAllTFTExpressed = fnmAllTFTExpressed;
		this.fnmAllTcoFTExpressed = fnmAllTcoFTExpressed;
		this.fnmTf_TcoFRepository = fnmTf_TcoFRepository;
		this.fnmOutput = fnmOutput;
	}



	





	void load_TF_TcoF_UniprotName()
	{
		String curLine;
		String tmp[] , tcofNames[];
		String tf;
		int ind;
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmTf_TcoFRepository);
		for(int i=0;i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);

			tmp = ConstantValue.patWhiteSpace.split(curLine);
			tf = tmp[0];
			tcofNames= ConstantValue.patSemiColon_Comma.split(tmp[1]);

			Set mySet = new LinkedHashSet();
			for(int c=0; c<tcofNames.length;c++)
			{
				mySet.add( tcofNames[c] );
			}


			lhm_TF_TcoF.put(tf, mySet);
		}

	}


	/*
	 *  1. Add all Expressed TF
	 *  2. Find intersection of (expressed TcoF) and (mapped TF from Expressed TF)
	 *  3. Union 1 and 2
	 */
	public void selectFor1cell(String curFold, String curFileTFExpressed , String curFileTcoFExpressed)
	{

		StringBuffer result = new StringBuffer();
		String curLine;
		String tmp[] , tfNames[];
		String geneID;
		int ind;
		
		LinkedHashMap<String, Set<String> > lhm_gene_TcoFExpressed   = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(curFold+"/" + curFileTcoFExpressed, 0 , 1);
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile( curFold + "/" + curFileTFExpressed);
		for(int i=0;i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);

			tmp = ConstantValue.patWhiteSpace.split(curLine);
			geneID = tmp[0];
			tfNames= ConstantValue.patSemiColon_Comma.split(tmp[1]);

			Set mySet_ExpressedTF = new LinkedHashSet();
			for(int c=0; c<tfNames.length;c++)
			{
				mySet_ExpressedTF.add( tfNames[c] );
			}


			/*
			 *  Now check TF -->TcoF
			 */

			Set mySet_ExpressedTF_AllTcof = new LinkedHashSet<String>();

			String[] arr = (String[]) mySet_ExpressedTF.toArray(new String[mySet_ExpressedTF.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			{

				if(lhm_TF_TcoF.containsKey(arr[c]))
				{

//					mySet_ExpressedTF_AllTcof.add(arr[c]); // add the TF
					mySet_ExpressedTF_AllTcof.addAll(   lhm_TF_TcoF.get(arr[c] ) ); // all the TcoF = Expressed + NonExpressed



				}


			} 



			Set intersection_TcoF_Expressed_Mapped = new LinkedHashSet<String>(mySet_ExpressedTF_AllTcof);
			if(lhm_gene_TcoFExpressed.containsKey( geneID ) ) {
				intersection_TcoF_Expressed_Mapped.retainAll (lhm_gene_TcoFExpressed.get(geneID) );
			}
			
			Set union = new LinkedHashSet<String>(mySet_ExpressedTF);
			union.addAll(intersection_TcoF_Expressed_Mapped);


			/*
			 *  Write the result
			 */

			if(union.size()>0)
			{
				result.append(  geneID +"\t");

				String[] arrFinal = (String[]) union.toArray(new String[union.size()]);
				int setSizeFinal = arrFinal.length;
				for(int c=0; c < setSizeFinal;c++)
				{
					if(c==setSizeFinal-1)
						result.append(   arrFinal[c]+"\n");
					else
						result.append(   arrFinal[c]+",");

				} 

//				result.append("\n");
			}


			
			

		} // iterate over each Gene

		
		String outputname = curFold + "/" + this.fnmOutput;
		System.out.println("Final output in: " + outputname);
		CommonFunction.writeContentToFile( outputname ,   result+"");

	}

	public void runItForAllCells()
	{
		/*
		 *  Iterate over all folders
		 */
		String curFolder , curCellLine ;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);

		for(int i=0; i< vectFolder.size() ;i++) // vectFolder.size()
		{
			curCellLine = vectFolder.get(i) ;
			curFolder = this.foldResultsCAGE+ "/" + curCellLine + "/";

			System.out.println(" Working for celline: "  + curFolder);
			

			selectFor1cell( curFolder , this.fnmAllTFTExpressed , this.fnmAllTcoFTExpressed);


//			if(curCellLine.equals("HEPG2"))
//			{
//				System.out.println("Work for it  HEPG2");
//				selectFor1cell( curFolder , this.fnmAllTFTExpressed , this.fnmAllTcoFTExpressed );
//
//			}

			
			


		}

	}

	void doProcessing()
	{

		load_TF_TcoF_UniprotName();
		runItForAllCells();

	}


	public static void main(String[] args) {


		CellLine_Specific_ConditionalTF_TcoF obj = new CellLine_Specific_ConditionalTF_TcoF(args[0], args[1], args[2], args[3], args[4]) ;

//		CellLine_Specific_ConditionalTF_TcoF obj = new CellLine_Specific_ConditionalTF_TcoF(
//				"./outFold/", 
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.bed.prom.bed.fa.map.bed.subselected.gene.tf",
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.bed.prom.bed.fa.map.bed.subselected.gene.tcof",
//				"TF_Tcof.Name.txt.highconf", 
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.bed.prom.bed.fa.map.bed.subselected.conditional.gene.tf.tcof") ;

		
		obj.doProcessing();

	}

}
