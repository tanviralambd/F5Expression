package f5expression.cage;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class IsItExpressedRefseq {


	String fnmMap_Refseq_Uniprot;
	String foldResultsCAGE;
	String fnmIntersect;
	String fnmOutput;



	LinkedHashMap<String, String> lhm_Refseq_Uniprot = new LinkedHashMap<String, String>();

	void loadMapping()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmMap_Refseq_Uniprot);
		String tmp[];
		String ref, uni;
		for(int i=0 ; i<vectAll.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			ref = tmp[0];
			uni = tmp[1];
			lhm_Refseq_Uniprot.put( ref, uni);
		}

	}


	/*
	 *  For Multiple UNIPROT_NAME for 1 Refse NM_
	 *  Take the last last NM_ expression value
	 */
	void generateUniprotExpressedList(String fold)
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfile( fold + "/" +  this.fnmIntersect);
		String tmp[];
		String nameRef, expVal , nameUniprot;
		LinkedHashMap<String, String> lhm_UNIPROTname_expValue = new LinkedHashMap<String, String>();

		StringBuffer bufRes = new StringBuffer();

		int totField;
		for(int i=0 ; i<vectAll.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			totField = tmp.length;

			nameRef   = tmp[3];
			expVal = tmp[totField-3];

			if(lhm_Refseq_Uniprot.containsKey(nameRef))
			{
				nameUniprot = lhm_Refseq_Uniprot.get(nameRef);
				lhm_UNIPROTname_expValue.put(nameUniprot, expVal);
			}else
			{
				nameUniprot = ConstantValue.noneStr;
				System.out.println("No mapping found for :" + nameRef ) ;
			}
			
		}

		System.out.println("Total unique UNIPROT entry found in this file: "+ lhm_UNIPROTname_expValue.size());


		/*
		 *  Write the result
		 */



		Set set = lhm_UNIPROTname_expValue.entrySet();
		
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String uniprotName = (String)me.getKey();
			String expV = (String) me.getValue();

			bufRes.append(uniprotName + "\t" + expV + "\n");
		}


		CommonFunction.writeContentToFile( fold + "/" +  this.fnmOutput, bufRes+"");


	}

	void doProcessing()
	{
		loadMapping();

		/*
		 *  Iterate over all folders
		 */
		String curFolder, curCellLine;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);
		for(int i=0; i< vectFolder.size() ;i++)
		{
			curCellLine = vectFolder.get(i); 
			curFolder = this.foldResultsCAGE+ "/" + curCellLine + "/";
			System.out.println("Checking expressed for "  + curFolder);
			
			generateUniprotExpressedList( curFolder);
			
//			if(curCellLine.equals("HEPG2"))
//			{
//				System.out.println("Work for it");
//			}
			
			
		}


	}


	public static void main(String[] args) {

		
		IsItExpressedRefseq obj = new IsItExpressedRefseq(args[0], args[1], args[2], args[3]);
		
		obj.doProcessing();
		
	}


	public IsItExpressedRefseq(String fnmMap_Refseq_Uniprot,
			String foldResultsCAGE, String fnmIntersect, String fnmOutput) {
		super();
		this.fnmMap_Refseq_Uniprot = fnmMap_Refseq_Uniprot;
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmIntersect = fnmIntersect;
		this.fnmOutput = fnmOutput;
	}

}
