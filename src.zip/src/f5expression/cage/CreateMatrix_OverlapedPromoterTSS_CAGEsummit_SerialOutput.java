package f5expression.cage;




import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.RestoreAction;

import f5expression.bean.BedFormat;
import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

/*
 *  Find the distance between 
 *   (TSS) and (CAGE Summit)
 *   1st file - MUST BE TSS. Format: BED
 *   2nd file - MUST BE CAGE CLUSTER. Format: Macrophage 
 *   
 *   Output:
 *   	Expression value in serial of input TSS bed file
 */

public class CreateMatrix_OverlapedPromoterTSS_CAGEsummit_SerialOutput {


	String fnmOnePromBed;
	String fnmTwoCAGEcsv;
	String fnmOutAnnotation;

	int upstream;
	int downstream;// if downstream is negative, then it means the whole gene body
	
	/*
	 *  1 - Nearest distance between TSS and 5'end
	 *  2 - Highest from all overlapping CAGE
	 *  3 - SUM of all overlapping CAGE
	 */
	int CHOICE= 0;

	/*
	 *  true -  input is promoter. Set upstream and downstream will not be used. So set them to ZERO  
	 *  false - input is TSS. So set upstream , donwstream = N bp
	 */
	boolean isPromoterInput;
	
	String extLibUnreadable=".libUnreadable";
	

	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState = new HashMap<String, Vector<BedFormat>>();
	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState2 = new HashMap<String, Vector<BedFormat>>();


	LinkedHashMap<String, Vector<Double>> lhm_cageID_expr = new LinkedHashMap<String, Vector<Double>>();
	Vector<String> vectHeaderDataPoint = new Vector<String>();
	Vector<String> vectLibSize = new Vector<String>();
	
	int totDataPoint;
	int totLibsizeTimePoint;

	
	String[] serialReslult;

	
	
	
	
	public CreateMatrix_OverlapedPromoterTSS_CAGEsummit_SerialOutput() {
		super();
	}


	public CreateMatrix_OverlapedPromoterTSS_CAGEsummit_SerialOutput(
			String fnmOnePromBed, String fnmTwoCAGEcsv,
			String fnmOutAnnotation, int upstream, int downstream, int cHOICE,
			boolean isPromoterInput) {
		super();
		this.fnmOnePromBed = fnmOnePromBed;
		this.fnmTwoCAGEcsv = fnmTwoCAGEcsv;
		this.fnmOutAnnotation = fnmOutAnnotation;
		this.upstream = upstream;
		this.downstream = downstream;
		CHOICE = cHOICE;
		this.isPromoterInput = isPromoterInput;
	}


	public void init(String fnm1, String fnm2, String fnmOut , String up, String down , String myChoice, String promoterInput)
	{

		this.fnmOnePromBed =  fnm1;
		this.fnmTwoCAGEcsv =    fnm2;

		this.fnmOutAnnotation =  fnmOut;		

		this.upstream = Integer.parseInt(up);
		this.downstream = Integer.parseInt(down);

		this.CHOICE = Integer.parseInt(myChoice);
		
		if( Integer.parseInt(promoterInput)==1)
		{
			System.out.println("Input is promoter, Not TSS");
			this.isPromoterInput = true;
			this.upstream    = 0;
			this.downstream  = 0 ;

		}else
		{
			this.isPromoterInput = false;
		}
		
	}


	/*
	 *  Check TSS bed file
	 */
	void loadTSSFromBed() {
		System.out.println("Extracting info ... ... ... ");
		String strLine = null;
		String tmp[];
		String curNameTSSorProm="";
		int index = 0;

		try {

			FileInputStream fstream = new FileInputStream(fnmOnePromBed);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));


			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = ConstantValue.patWhiteSpace.split(strLine);

				curNameTSSorProm = CommonFunction.getUniqueNameFromBed_0based(tmp[0], tmp[1] , tmp[2] , tmp[5]);
				
				try {
					addInChrMap( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  curNameTSSorProm, tmp[4]  , tmp[5].charAt(0) , index ); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total entry in the promoter file:" + index);
			
			serialReslult = new String[index];
			  // more to the class here ...
			
			
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}





	void addInChrMap( String chrm, int start, int end,   String name, String score ,char strand , String CDSstart, String CDSend) {

		try {
			BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand, Integer.parseInt(CDSstart) , Integer.parseInt(CDSend) );

			if (mapChrmWisePromoterState.containsKey(chrm)) {
				mapChrmWisePromoterState.get(chrm).add(pm);
			} else {
				Vector<BedFormat> vp = new Vector<BedFormat>();
				vp.add(pm);
				mapChrmWisePromoterState.put(chrm, vp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Err for "+ chrm +"\t"+ start +"\t" + end +"\t" + name +"\t"  + score +"\t"  + strand);
		}


	}
	
	void addInChrMap( String chrm, int start, int end,   String name, String score ,char strand, int index0basedInputFile) {

		try {
			BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand,index0basedInputFile );

			if (mapChrmWisePromoterState.containsKey(chrm)) {
				mapChrmWisePromoterState.get(chrm).add(pm);
			} else {
				Vector<BedFormat> vp = new Vector<BedFormat>();
				vp.add(pm);
				mapChrmWisePromoterState.put(chrm, vp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Err for "+ chrm +"\t"+ start +"\t" + end +"\t" + name +"\t"  + score +"\t"  + strand);
		}


	}
	


	void addInChrMap2( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState2.containsKey(chrm)) {
			mapChrmWisePromoterState2.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState2.put(chrm, vp);
		}
	}


	void loadCAGEfromTabDelimitedFile() {
		System.out.println("Extracting CAGE info ... ... ... ");
		String strLine = null;
		String tmp[], cageSplit[];

		String cageID;


		int index = 0;
		int start_Exp_0based=1;

		Vector<Double> curExpVect ;

		try {

			FileInputStream fstream = new FileInputStream(fnmTwoCAGEcsv);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			// 1st line - handle header
			String headerLine = br.readLine();
			String tmpHeader[] = ConstantValue.patTabSingle.split(headerLine);
			for(int v=start_Exp_0based; v<tmpHeader.length;v++)
			{
				vectHeaderDataPoint.add(tmpHeader[v] ) ;
			}
			totDataPoint = vectHeaderDataPoint.size();
			System.out.println("Total dataPoint in this file: "+ totDataPoint);

			
			// 2nd line - Library Size
			String libsizeLine = br.readLine();
			String tmpLibsize[] = ConstantValue.patTabSingle.split(libsizeLine);
			for(int v=start_Exp_0based; v<tmpLibsize.length;v++)
			{
				vectLibSize.add(tmpLibsize[v] ) ;
			}
			totLibsizeTimePoint = vectLibSize.size();
			System.out.println("Total libSize Entry in this file: "+ totLibsizeTimePoint);
			int lineNo=3;
			
			
			// 3rd line - Skip
			
			br.readLine();
			
			// 4th - last Line
			while ((strLine = br.readLine()) != null) {
//				System.out.println("Working With line no:"+ (lineNo++)  );
				tmp = ConstantValue.patTabSingle.split(strLine);

				// handling ID
				cageID = tmp[0];
				cageSplit = ConstantValue.patFantom5Cage.split( cageID );
				addInChrMap2 ( cageSplit[0], Integer.parseInt( cageSplit[1])-1 , Integer.parseInt(cageSplit[2])   ,  tmp[0], "0" , cageSplit[3].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				// handle the Expression values

				curExpVect = new Vector<Double>();
				for(int v=start_Exp_0based; v<tmp.length;v++)
				{
					curExpVect.add(Double.parseDouble(tmp[v])) ;
				}
				//				if( (tmp.length - start_Exp_0based) !=36)
				//				System.out.println("Total dataPoint in this cluster: "+ cageID  + "\t"+ (tmp.length - start_Exp_0based) ) ;

				lhm_cageID_expr.put(cageID, curExpVect);

				index++;

			}


			System.out.println("Total CAGE cluster in the file:" + index); 
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void find_NearestDistance_Prom_CAGE()
	{
		int minDist = Integer.MAX_VALUE;
		int distTSS_cagemidpoint=0;
		String targetCage=null;
		
		
		String curLineResult;
		StringBuffer bufTSS_CageResult = new StringBuffer();
		
		StringBuffer expValue = new StringBuffer();
		
		// Append header in output - buffer
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				expValue.append(vectHeaderDataPoint.get(d));
			else
				expValue.append(vectHeaderDataPoint.get(d)+"\t");

		}

		bufTSS_CageResult.append(  "TrxID" + "\t"  +	"CageID" + "\t" +  expValue + "\n"  );
		
		// dummyExp In case of NO-MAPPING
		StringBuffer dummyExp = new StringBuffer();
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				dummyExp.append(ConstantValue.noneVal);
			else
				dummyExp.append(ConstantValue.noneVal+"\t");

		}
		String otherDummy= ConstantValue.noneStr +"\t" + ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr  ;
		try {
			//			BufferedWriter bwr = new BufferedWriter(new FileWriter( this.fnmOut));
			
			//			StringBuffer bufTSS_TIS = new StringBuffer();

			Set setChrm = mapChrmWisePromoterState.entrySet();
			Set setChrm2 = mapChrmWisePromoterState2.entrySet();

			int promStartCoord=0, promEndCoord=0;
			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				String currentChrm = (String)me.getKey();

				/*
				 *  Promoters
				 */
				Vector<BedFormat> vp = (Vector<BedFormat>) me.getValue();
				/*
				 *  CAGE clusters
				 */
				Vector<BedFormat> vp2 =  mapChrmWisePromoterState2.get(currentChrm);
				
				if(vp2==null)
					System.out.println("No peak found for chromosome: "+ currentChrm) ;
				for(int i=0;  i<vp.size() ;i++)
				{

					if(this.isPromoterInput) // input is promoter
					{
						promStartCoord  =  vp.get(i).getStart() ;
						promEndCoord    =  vp.get(i).getEnd() ;
					}else // input is TSS 
					{
							if(downstream <0) // Consider the whole gene body as downstream
						{
							promStartCoord  = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() - upstream    :  vp.get(i).getStart()          ;
							promEndCoord    = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getEnd()                 :  vp.get(i).getEnd() + upstream ;
	
							
						}else // Normal Downstream Region
						{
							promStartCoord  = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() - upstream    :  vp.get(i).getEnd() - downstream;
							promEndCoord    = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() + downstream  :  vp.get(i).getEnd() + upstream ;
	
						}
						
					}
					
					
					
					  
					/*
					 *  Select ONE CAGE with min distance , TSS & (CAGE 5'end)
					 */
					if(vp2 != null)
					{
						minDist = Integer.MAX_VALUE;

						for(int j=0; j<vp2.size();j++)
						{
							if(vp.get(i).getStrand() == vp2.get(j).getStrand())
							{


								if ( CommonFunction.isOverlap( promStartCoord, promEndCoord ,vp2.get(j).getStart() ,vp2.get(j).getEnd() ) )
								{

									// based on nearest distance between (TSS) and (mid of CAGE cluster)
//									distTSS_cagemidpoint = Math.abs(      vp.get(i).getTss() - vp2.get(j).getMidPoint()   ) ;
									
									// based on nearest distance between (TSS) and ( 5' end of CAGE cluster)
									distTSS_cagemidpoint = Math.abs( vp.get(i).getTss() - vp2.get(j).getTss()   ) ;
									
									
									if(distTSS_cagemidpoint < minDist)
									{
										minDist = distTSS_cagemidpoint ;
										targetCage =   vp2.get(j).getName() ;
									}

								}
							}
						} // iterate over all CAGE to select one with minimum distance

						if(minDist != Integer.MAX_VALUE) // no chipSeqPeak in promoter is found
						{

							expValue = new StringBuffer();
							for(int d=0;d<totDataPoint;d++)
							{
								if(d==totDataPoint-1)
									expValue.append(lhm_cageID_expr.get(targetCage).get(d));
								else
									expValue.append(lhm_cageID_expr.get(targetCage).get(d)+"\t");

							}

							curLineResult= vp.get(i).getName() + "\t"  +	targetCage + "\t" +  expValue + "\n" ;
							serialReslult[vp.get(i).getIndexSeq_0_Based()] = curLineResult;
							bufTSS_CageResult.append(  curLineResult  );

						}else
						{
							curLineResult= vp.get(i).getName() +  "\t" +	ConstantValue.noneStr     + "\t" +  dummyExp + "\n"  ;
							serialReslult[vp.get(i).getIndexSeq_0_Based()] = curLineResult;
							bufTSS_CageResult.append(  curLineResult );

						}


					}

				} // iterate over all promoters

			}


			for(int r=0;r< serialReslult.length;r++)
			{
				bufTSS_CageResult.append(serialReslult[r]);
			}
			CommonFunction.writeContentToFile(this.fnmOutAnnotation, bufTSS_CageResult+"");
			//			CommonFunction.writeContentToFile(this.fnmOut+".TSS_TIS.dist", bufTSS_TIS+"");



		} catch (Exception e) {
			e.printStackTrace();
		}




	}

	
	
	
	void find_Highest_OR_Sum_Prom_CAGE()
	{
		boolean foundOverlap = false;
		int distTSS_cagemidpoint=0;
		String targetCageID=null;
		
		String curLineResult;
		StringBuffer bufTSS_CageResult = new StringBuffer();
		StringBuffer expValue = new StringBuffer();
		int index0based=0;
		
		Vector< Vector<Double>> vectCageVector ;
		Vector< String> vectCageVectorID ;
		int totalCAGEoverlap;
		Vector<Double> vectExps;
		double finalValue=0.0;

		
		StringBuffer overlapCages = new StringBuffer();
		
		// Append header in output - buffer
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				expValue.append(vectHeaderDataPoint.get(d));
			else
				expValue.append(vectHeaderDataPoint.get(d)+"\t");

		}

		bufTSS_CageResult.append(  "TrxID" + "\t"  +	"CageID" + "\t" +  expValue + "\n"  );
		
		// Prepare dummyExp In case of NO-MAPPING
		StringBuffer dummyExp = new StringBuffer();
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				dummyExp.append(ConstantValue.noneVal);
			else
				dummyExp.append(ConstantValue.noneVal+"\t");

		}
		String otherDummy= ConstantValue.noneStr+"\t" + ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr +"\t"+ ConstantValue.noneStr  ;
		
		
		/*
		 *  Now check promoter with CAGE
		 */
		
		try {
		

			Set setChrm = mapChrmWisePromoterState.entrySet();
			Set setChrm2 = mapChrmWisePromoterState2.entrySet();

			int promStartCoord=0, promEndCoord=0;
			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				String currentChrm = (String)me.getKey();

				Vector<BedFormat> vp = (Vector<BedFormat>) me.getValue();
				Vector<BedFormat> vp2 =  mapChrmWisePromoterState2.get(currentChrm);
				if(vp2==null)
					System.out.println("No peak found for chromosome: "+ currentChrm) ;
				
				for(int i=0;  i<vp.size() ;i++)
				{

					
					if(this.isPromoterInput) // input is promoter
					{
						promStartCoord  =  vp.get(i).getStart() ;
						promEndCoord    =  vp.get(i).getEnd() ;
					}else{ // input is TSS 
						
						if(downstream <0) // Consider the whole gene body as downstream
						{
							promStartCoord  = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() - upstream    :  vp.get(i).getStart()          ;
							promEndCoord    = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getEnd()                 :  vp.get(i).getEnd() + upstream ;
						}else // Normal Downstream Region
						{
							promStartCoord  = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() - upstream    :  vp.get(i).getEnd() - downstream;
							promEndCoord    = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() + downstream  :  vp.get(i).getEnd() + upstream ;
						}
					
					}
					
					
					
					if(vp2 != null)
					{
						foundOverlap = false;

						vectCageVector = new Vector<Vector<Double>>();
						vectCageVectorID = new Vector<String>();
						
						for(int j=0; j<vp2.size();j++)
						{
							if(vp.get(i).getStrand() == vp2.get(j).getStrand())
							{
								

								if ( CommonFunction.isOverlap( promStartCoord, promEndCoord ,vp2.get(j).getStart() ,vp2.get(j).getEnd() ) )
								{
									foundOverlap = true;
									// based on signal
									targetCageID =   vp2.get(j).getName() ;
									vectCageVector.add( lhm_cageID_expr.get(targetCageID) );
									vectCageVectorID.add(targetCageID);
								}
							}
						}

						totalCAGEoverlap = vectCageVector.size();
						
						
						
						if(foundOverlap ) 
						{
							expValue = new StringBuffer();
							
							/*
							 *  Do same for each repeat
							 */
							for(int d=0;d<totDataPoint;d++)
							{
								vectExps = new Vector<Double>();
								
								for(int k=0; k< totalCAGEoverlap;k++)
								{
									vectExps.add( vectCageVector.get(k).get(d) );
								}
								
								/*
								 *  Find finalvalue, finalCAGEID
								 */
								if(this.CHOICE ==3) // SUM of all CAGE
								{
									finalValue = myCAGEFnc_Sum(vectExps);
									overlapCages = new StringBuffer();
									for(int k=0; k< totalCAGEoverlap;k++)
									{
										overlapCages.append( vectCageVectorID.get(k) +";" );
									}
								}else if(this.CHOICE==2) // MAXIMUM from all CAGE
								{
//									System.out.println(" vectExps.size():"+vectExps.size() + "  vectCageVectorID.size():" + vectCageVectorID.size());
									index0based = myCAGEFnc_Max(vectExps);
									
									// value
									finalValue = vectExps.get(index0based);
									
									// CAGE ID
									overlapCages = new StringBuffer();
									overlapCages.append( vectCageVectorID.get(index0based) + "" );
									
									
								}
								
								
								
								if(d==totDataPoint-1){
									
									expValue.append( finalValue);
								}									
								else{
									
									expValue.append( finalValue+"\t");
								}

							}

							curLineResult = vp.get(i).getName() + "\t"  +	overlapCages + "\t" +  expValue + "\n"  ;
							serialReslult[vp.get(i).getIndexSeq_0_Based()] = curLineResult;
//							bufTSS_CageResult.append(  curLineResult);

						}else
						{
							curLineResult = vp.get(i).getName() +  "\t" +	ConstantValue.noneStr     + "\t" +  dummyExp + "\n"   ;
							serialReslult[vp.get(i).getIndexSeq_0_Based()] = curLineResult;
//							bufTSS_CageResult.append( curLineResult );

						}


					}// end of all CAGE of a chromosome which match the TRX

				}// end of a TRX

			}


			for(int r=0;r< serialReslult.length;r++)
			{
				bufTSS_CageResult.append(serialReslult[r]);
			}
			
			CommonFunction.writeContentToFile(this.fnmOutAnnotation, bufTSS_CageResult+"");
			



		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	double myCAGEFnc_Sum(Vector<Double> input)
	{
		double rsultCageExpression=0.0;
		
		switch (CHOICE) {
//			case 2: //MAX
//				
//				for (int i=0; i < input.size(); i++) {
//			        if (input.get(i) > rsultCageExpression ) 
//			            rsultCageExpression = input.get(i);
//			    }
//				break;
	
			case 3: // SUM
				for(int i=0;i<input.size();i++)
				{
					rsultCageExpression = rsultCageExpression + input.get(i);
				}
				break;
		
			default:
				break;
		}
		
		return rsultCageExpression;
	}
	
	
	int  myCAGEFnc_Max(Vector<Double> input)
	{
		int index0based=0;
		double resultCageExpression=0.0;
		switch (CHOICE) {
			case 2: //MAX
				
				for (int i=0; i < input.size(); i++) {
			        if (input.get(i) > resultCageExpression ){ 
			            resultCageExpression = input.get(i);
			            index0based = i;
			        }
			    }
				break;
	
					
			default:
				break;
		}
		
		return index0based;
	}
	
	
	void writeNonReadableLibrarySize()
	{
		StringBuffer libSize_Head_Value = new StringBuffer();
		
		// Append header in output - buffer
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				libSize_Head_Value.append(vectHeaderDataPoint.get(d));
			else
				libSize_Head_Value.append(vectHeaderDataPoint.get(d)+"\t");

		}
		
		libSize_Head_Value.append("\n");
		

		for(int d=0;d<totLibsizeTimePoint;d++)
		{
			if(d==totLibsizeTimePoint-1)
				libSize_Head_Value.append(vectLibSize.get(d));
			else
				libSize_Head_Value.append(vectLibSize.get(d)+"\t");

		}

		CommonFunction.writeContentToFile( this.fnmTwoCAGEcsv+ this.extLibUnreadable , libSize_Head_Value+"");
		
	}
	
	void doProcessing()
	{
		loadTSSFromBed();
		
		loadCAGEfromTabDelimitedFile();

		switch (CHOICE) {
		case 1: // Nearest distance between TSS and 5'end
			find_NearestDistance_Prom_CAGE();
			break;
		case 2: // Highest from all overlapping CAGE
		case 3: // Sum  of all overlapping CAGE
			find_Highest_OR_Sum_Prom_CAGE();
			break;
			

		default: // Nearest Distance
			find_NearestDistance_Prom_CAGE(); 
			break;
		}
		
		writeNonReadableLibrarySize();


	}

	public static void main(String[] args) {

		CreateMatrix_OverlapedPromoterTSS_CAGEsummit_SerialOutput obj = new CreateMatrix_OverlapedPromoterTSS_CAGEsummit_SerialOutput();

//	    obj.init("F5_robust_DPI_TSS_nonCoding_only.bed","GM12878_FANTOM_expression.txt", "F5_robust_DPI_TSS_nonCoding_only.bed.Gm12878.annotation", "500", "500", "3" , "0");
	
//	    obj.init("F5_robust_DPI_TSS_500_upstream_500_downstream_nonCoding_only.bed","GM12878_FANTOM_expression.txt", "F5_robust_DPI_TSS_500_upstream_500_downstream_nonCoding_only.bed.Gm12878.annotation", "500", "500", "3" , "1");
		
	    
	    
		obj.init(args[0], args[1], args[2] , args[3] , args[4] , args[5], args[6]);

		obj.doProcessing();



	}


}



