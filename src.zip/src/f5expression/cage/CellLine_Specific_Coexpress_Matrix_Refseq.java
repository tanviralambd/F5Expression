package f5expression.cage;

import java.util.LinkedHashMap;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class CellLine_Specific_Coexpress_Matrix_Refseq {

	
	
	String fnmMap_Uniprot_Refseq;
	String foldResultsCAGE;
	String fnmExprList;
	String fnmOutput;


	
	LinkedHashMap<String, Integer> lhm_Uniprot_Refseq_Index = new LinkedHashMap<String, Integer>();
	StringBuffer bufMatrix = new StringBuffer();

	void loadMapping()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmMap_Uniprot_Refseq);
		String tmp[];
		String ref, uni;
		for(int i=0 ; i<vectAll.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));

			
			uni = tmp[1];
			ref = tmp[2];
			lhm_Uniprot_Refseq_Index.put( uni, i);
		}

		System.out.println(" Total Unique Uniprot Name: "+lhm_Uniprot_Refseq_Index.size());
		
	}
	
	
	void merge1cell(String curFolder)
	{
		
		Vector<String> vectAllExrp = CommonFunction.readlinesOfAfile(curFolder + "/" + this.fnmExprList ) ;
		
		String tmp[];
		String uni, exprVal;
		int curIndex;
		
		float arrExpr[] = new float[ lhm_Uniprot_Refseq_Index.size() ];
		
		for(int i=0;  i<vectAllExrp.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAllExrp.get(i));
			uni = tmp[0];
			exprVal = tmp[1];
			curIndex = lhm_Uniprot_Refseq_Index.get(uni);
			
			arrExpr[ curIndex] = Float.parseFloat( exprVal  );
			
			
		}
		
		
		for( int k=0 ; k<arrExpr.length;k++)
		{
			if(k == (arrExpr.length -1) )
				bufMatrix.append(arrExpr[k]  + "\n"  );
			else
				bufMatrix.append(arrExpr[k]  + "," );
		}
		
		
	}
	
	
	void workForAll()
	{
		/*
		 *  Iterate over all folders
		 */
		String curFolder, curCellLine;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);
		for(int i=0; i< vectFolder.size() ;i++)
		{
			curCellLine = vectFolder.get(i); 
			curFolder = this.foldResultsCAGE+ "/" + curCellLine + "/";
			
			System.out.println("Checking expressed for "  + curFolder);
			merge1cell( curFolder);
			
//			if(curCellLine.equals("HEPG2"))
//			{
//				System.out.println("Work for it");
//				merge1cell( curFolder);
//			}
			
			
			
			
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOutput, bufMatrix + "");
		
	}
	
	void doProcessing()
	{
		loadMapping();
		
		workForAll();
		
	}
	
	
	
	
	
	public CellLine_Specific_Coexpress_Matrix_Refseq(String fnmMap_Uniprot_Refseq,
			String foldResultsCAGE, String fnmExprList, String fnmOutput) {
		super();
		this.fnmMap_Uniprot_Refseq = fnmMap_Uniprot_Refseq;
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmExprList = fnmExprList;
		this.fnmOutput = fnmOutput;
	}


	public static void main(String[] args) {
		
		
		CellLine_Specific_Coexpress_Matrix_Refseq obj = new CellLine_Specific_Coexpress_Matrix_Refseq( args[0],  args[1],  args[2],  args[3] );
		
//		CellLine_Specific_Coexpress_Matrix_Refseq obj = new CellLine_Specific_Coexpress_Matrix_Refseq(
//				"./swissprot_refgeneNM_human_download.tab",  
//				"./outFold/",  
//				"refGene_NM.hg19.txt.prom.bed.cage.intersect.bed.expressed",  
//				"expression.matrix" );
		

		
		obj.doProcessing();
		
	}
	
}
