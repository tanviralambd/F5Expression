package f5expression.cage;

import java.util.Vector;

import f5expression.folderoperation.FolderOperations;

public class CellLine_Specific_SubselectTFTcoF  {



	String foldResultsCAGE;
	String fnmExpressedProtein;
	String fnmExpressedRNA;

	String fnmTFTcoFCommon;
	String fnmOutput;


	public void runIt()
	{
		/*
		 *  Iterate over all folders
		 */
		String curFolder , curCellLine;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);

		for(int i=0; i< vectFolder.size() ;i++) // vectFolder.size()
		{
			curCellLine = vectFolder.get(i) ;
			curFolder = this.foldResultsCAGE+ "/" + curCellLine + "/";

			System.out.println("Subselecting TF-TcoF for "  + curFolder);
			SelectOnlyExpressedGeneFromMapping selectObj = new SelectOnlyExpressedGeneFromMapping(

					curFolder + this.fnmExpressedProtein, 
					curFolder + this.fnmExpressedRNA, 
					this.fnmTFTcoFCommon, 
					curFolder + this.fnmOutput);

			selectObj.doProcessing();


			//			if(curCellLine.equals("HEPG2"))
			//			{
			//				System.out.println("Work for it");
			//			}



		}

	}

	void doProcessing()
	{

		runIt();

	}





	public CellLine_Specific_SubselectTFTcoF(String foldResultsCAGE,
			String fnmExpressedProtein, String fnmExpressedRNA,
			String fnmTFTcoFCommon, String fnmOutput) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmExpressedProtein = fnmExpressedProtein;
		this.fnmExpressedRNA = fnmExpressedRNA;
		this.fnmTFTcoFCommon = fnmTFTcoFCommon;
		this.fnmOutput = fnmOutput;
	}

	public static void main(String[] args) {


		CellLine_Specific_SubselectTFTcoF obj = new CellLine_Specific_SubselectTFTcoF(args[0], args[1], args[2] , args[3], args[4]);

		obj.doProcessing();

	}




}
