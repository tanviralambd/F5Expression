package f5expression.cage;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

public class IsItExpressedLncRNA {


//	String fnmMap_Refseq_Uniprot;
	String foldResultsCAGE;
	String fnmIntersect;
	String fnmOutput;



//	LinkedHashMap<String, String> lhm_Refseq_Uniprot = new LinkedHashMap<String, String>();
//
//	void loadMapping()
//	{
//		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmMap_Refseq_Uniprot);
//		String tmp[];
//		String ref, uni;
//		for(int i=0 ; i<vectAll.size() ; i++)
//		{
//			tmp = ConstantValue.patTab.split(vectAll.get(i));
//
//			ref = tmp[0];
//			uni = tmp[1];
//			lhm_Refseq_Uniprot.put( ref, uni);
//		}
//
//	}


	void generateLncRNAExpressedList(String fold)
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfile( fold + "/" +  this.fnmIntersect);
		String tmp[];
		String nameRef, expVal;
		LinkedHashMap<String, String> lhm_LNCRNAname_expValue = new LinkedHashMap<String, String>();

		StringBuffer bufRes = new StringBuffer();

		int totField;
		for(int i=0 ; i<vectAll.size() ; i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			totField = tmp.length;

			nameRef   = tmp[3];
			expVal = tmp[totField-3];
			lhm_LNCRNAname_expValue.put(nameRef, expVal);

			
		}

		System.out.println("Total unique LNCrna entry found in this file: "+ lhm_LNCRNAname_expValue.size());


		/*
		 *  Write the result
		 */
	


		Set set = lhm_LNCRNAname_expValue.entrySet();
		
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Map.Entry me = (Map.Entry) itr.next();
			String lncrnaName = (String)me.getKey();
			String expV = (String) me.getValue();

			bufRes.append(lncrnaName + "\t" + expV + "\n");
		}


		CommonFunction.writeContentToFile( fold + "/" +  this.fnmOutput, bufRes+"");


	}

	void doProcessing()
	{
//		loadMapping();

		/*
		 *  Iterate over all folders
		 */
		String curFolder;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);
		for(int i=0; i< vectFolder.size() ;i++)
		{
			curFolder = this.foldResultsCAGE+ "/" + vectFolder.get(i) + "/";
			System.out.println("Checking expressed for "  + curFolder);
			generateLncRNAExpressedList( curFolder);
		}


	}

	
	public IsItExpressedLncRNA(
			String foldResultsCAGE, String fnmIntersect, String fnmOutput) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmIntersect = fnmIntersect;
		this.fnmOutput = fnmOutput;
	}
	

	public static void main(String[] args) {

		
		IsItExpressedLncRNA obj = new IsItExpressedLncRNA(args[0], args[1], args[2] );
		
		obj.doProcessing();
		
	}

	



}
