package f5expression.cage;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class ListHeaderReadable {

	String fin;
	String fout;
	
	void makeHeaderList(String fi, String fo , String skipColumn) {
		
		this.fin =fi;
		this.fout = fo;
		
		int skip_starting_columns= Integer.parseInt(skipColumn);

		StringBuffer bufHead = new StringBuffer();

		try {

			FileInputStream fstream = new FileInputStream(fin);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			// 1st line - handle header
			String headerLine = br.readLine();
			String tmpHeader[] = ConstantValue.patTabSingle.split(headerLine);
			for(int v=skip_starting_columns; v<tmpHeader.length;v++)
			{
				bufHead.append(  CommonFunction.makeReadable_FANTOMheader( tmpHeader[v] ) +"\n") ;
			}

			int selectedDataPoint = tmpHeader.length - skip_starting_columns;
			System.out.println("Total dataPoint in header: "+ tmpHeader.length);
			System.out.println("Skip dataPoint: "+ skip_starting_columns);
			System.out.println("Selected dataPoint: "+ selectedDataPoint);

			// 2nd line - skip it
//			br.readLine();

			br.close();
			in.close();
			fstream.close();
			
			
			CommonFunction.writeContentToFile(fout, bufHead+"") ;
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
		ListHeaderReadable obj = new ListHeaderReadable();
		
//		obj.makeHeaderList(args[0], args[1] , args[2]);
		
		obj.makeHeaderList("hg19.cage_peak_relative_expr.txt.header", "hg19.cage_peak_relative_expr.txt.header.readable" , "1");
		
	}
}
