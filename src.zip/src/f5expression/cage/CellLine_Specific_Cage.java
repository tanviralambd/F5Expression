package f5expression.cage;

import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

/*
 *  Cut the RLE values of CAGE clsuter column, which match input cellline name
 */
public class CellLine_Specific_Cage {

	
	String cellLine="";
	String fnmAllCage="";
	String fnmCellLineCage="";
	
	Vector<String> vectAll;
	
	void init(String celLine, String inputfile, String outputFile)
	{
		this.cellLine = celLine;
		this.fnmAllCage = inputfile;
		this.fnmCellLineCage = outputFile;
	}
	
	
	
	void checkCellLine()
	{
		String header = vectAll.get(0);
		
		String columnNames[];
		
		
		int skipfirstColumn=1;
		columnNames = ConstantValue.patWhiteSpace.split(header);
		Pattern pat_Cell = Pattern.compile(this.cellLine);
		
		/*
		 *  find the column index matching cell line name
		 */
		String curName;
		Vector<Integer> vectMatchIndex = new Vector<Integer>();
		for(int i= skipfirstColumn ;i<columnNames.length;i++)
		{
			curName = columnNames[i];
			
			Matcher m=  pat_Cell.matcher(curName) ;
			if(m.find())
			{
				vectMatchIndex.add(i);
			}
			
		}
		
		/*
		 * Now take the column index and corresponding values
		 */
		
		String tmp[];
		StringBuffer buf = new StringBuffer();
		
		
		
		tmp = ConstantValue.patWhiteSpace.split(vectAll.get(0));
		if(vectMatchIndex.size()>0)
		{
			
			// HEADERS CHANGE NAME
			buf.append(tmp[0]+"\t");
			
			for(int j=0; j<vectMatchIndex.size();j++)
			{
				if(j==vectMatchIndex.size()-1)
					buf.append( CommonFunction.makeReadable_FANTOMheader(  tmp[vectMatchIndex.get(j)] )+"\n");
				else
					buf.append( CommonFunction.makeReadable_FANTOMheader(  tmp[vectMatchIndex.get(j)] ) +"\t");
			}
			
			// DATAS
			for(int i=1; i<vectAll.size();i++)
			{
				tmp = ConstantValue.patWhiteSpace.split(vectAll.get(i));
				buf.append(tmp[0]+"\t");
				for(int j=0; j<vectMatchIndex.size();j++)
				{
					if(j==vectMatchIndex.size()-1)
						buf.append( tmp[vectMatchIndex.get(j)]+"\n");
					else
						buf.append( tmp[vectMatchIndex.get(j)]+"\t");
				}
			}
			
			
			
			
		}
		
		
		

		
		/*
		 *  write the result
		 */
		
		CommonFunction.writeContentToFile(this.fnmCellLineCage, buf+"");
		
	}
	
	void loadAllData()
	{
		vectAll = CommonFunction.readlinesOfAfile(this.fnmAllCage);
	}
	
	void doProcessing()
	{
		
		loadAllData();
		checkCellLine();
	}
	
	

	
	public static void main(String[] args) {
		
		
		CellLine_Specific_Cage obj = new CellLine_Specific_Cage();
		
		
//		obj.init(args[0], args[1], args[2]);
		
//		String cell="K562";
//		String cell="GM12878";
		
//		String cell="H9ES"; // "H1hesc"; FOR Embryonic Stem Cell
//		obj.init(cell, "hg19.cage_peak_relative_expr.txt.header", "hg19.cage_peak_relative_expr.txt.header"+"."+cell);;
		
		
		obj.doProcessing();
		
	
		
		
		
	}
	
}
