package f5expression.cage;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;

public class SelectOnlyExpressedGeneFromMapping {

	String fnmExprProteins;
	String fnmExprRNAs;
	
	String fnmInputMapping;
	String fnmOut;
	
	
	
	LinkedHashMap<String, Float>  lhm_Protein_Expr = new LinkedHashMap<String, Float>(); 
	LinkedHashMap<String, Float>  lhm_RNA_Expr = new LinkedHashMap<String, Float>(); 
	
	


	
	public SelectOnlyExpressedGeneFromMapping(String fnmExprProteins, String fnmExprRNAs,
			String fnmInputMapping, String fnmOut) {
		super();
		this.fnmExprProteins = fnmExprProteins;
		this.fnmExprRNAs = fnmExprRNAs;
		this.fnmInputMapping = fnmInputMapping;
		this.fnmOut = fnmOut;
		
		System.out.println(this.fnmExprProteins );
		System.out.println(this.fnmExprRNAs);
		System.out.println(this.fnmInputMapping);
		System.out.println(this.fnmOut);
		
		
		
	}


	void loadExpressedGenes()
	{
		
		String tmp[];
		
		Vector<String> vectorProtein = CommonFunction.readlinesOfAfile(this.fnmExprProteins);
		for(int i=0; i<vectorProtein.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectorProtein.get(i))  ;
			
			lhm_Protein_Expr.put(tmp[0], Float.parseFloat(tmp[1])  );
			
		}
		
		Vector<String> vectorRNA = CommonFunction.readlinesOfAfile(this.fnmExprRNAs);
		for(int i=0; i<vectorRNA.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectorRNA.get(i))  ;
			
			lhm_RNA_Expr.put(tmp[0], Float.parseFloat(tmp[1])  );
			
		}
		
		
	}
	
	
	void subselectExpressedGene()
	{
		
		Vector<String> vectorRNA_prot_mapping = CommonFunction.readlinesOfAfile(this.fnmInputMapping);

		String tmp[] , tmpTF[];
		String curRNA;

		String selectedRNA, selectdTFTcoF;
		StringBuffer resultBuffer = new StringBuffer();
		
		
		for(int i=0; i<vectorRNA_prot_mapping.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectorRNA_prot_mapping.get(i))  ;

			curRNA = tmp[0];
			tmpTF = ConstantValue.patSemiColon_Comma.split(tmp[1]);
			
			if( lhm_RNA_Expr.containsKey(curRNA))
			{
				selectedRNA = curRNA;
				
				/*
				 *  Select Expressed TF-TcoFs
				 */
				Set<String> selectedTF = new LinkedHashSet<String>();
				for(int t=0 ; t<tmpTF.length ;t++)
				{
					if(  lhm_Protein_Expr.containsKey( tmpTF[t])  )
					{
						selectedTF.add(tmpTF[t] );
					}
					
				}
				
				/*
				 *  Write the result
				 */
				if(selectedTF.size()>0)
				{
					resultBuffer.append(selectedRNA +"\t");
					
					String[] arr = (String[]) selectedTF.toArray(new String[selectedTF.size()]);
					int setSize = arr.length;
					for(int c=0; c < setSize;c++)
					 {
					  if(c==setSize-1)
						  resultBuffer.append(arr[c]+"\n");
					  else
						  resultBuffer.append(arr[c]+";");

					} 
					
					
					
				}
				
			}

		}
		
		
		CommonFunction.writeContentToFile(this.fnmOut, resultBuffer+"");
		
	}

	void doProcessing()
	{
		
		
		loadExpressedGenes();
		subselectExpressedGene();
		
		
	}
	
	
	public static void main(String[] args) {
		
		SelectOnlyExpressedGeneFromMapping obj = new SelectOnlyExpressedGeneFromMapping(args[0], args[1], args[2] , args[3]);
		
//		SelectOnlyExpressedGeneFromMapping obj = new SelectOnlyExpressedGeneFromMapping(
//				"refGene_NM.hg19.txt.prom.bed.cage.intersect.bed.expressed", 
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.promoter.bed.cage.intersect.bed.expressed", 
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.bed.prom.bed.fa.map.bed.gene.tf.tcof", 
//				"gencode.v19.long_noncoding_RNAs.gtf.transcript.bed.prom.bed.fa.map.bed.gene.tf.tcof.cellspecific");
		
		obj.doProcessing();
		
	}
	
	
}
