package f5expression.cage;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import javax.sql.CommonDataSource;

import f5expression.common.CommonFunction;
import f5expression.constant.ConstantValue;
import f5expression.folderoperation.FolderOperations;

/*
 *  Create shell-script command to check oerlap
 */
public class Command_Caller_CAGE_Cellspecific {

	
	String fnmFile_Cellline;
	String foldInputCAGE;
	String foldOutputResult;
	
	
	String fnmOnePromBed;
	String fnmTwoCAGEBed;
	String fnmCommandOutput;
	String fnmHeaderShell;
	
	
	
	Set<String> setCell;
	Vector<String> vectInputFiles;
	Vector<String> vectOutputFiles;
	
	
	void loadUniqueCellLines()
	{
		 setCell = new LinkedHashSet<String>();
		 Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmFile_Cellline);
		 String tmp[];
		 
		 for(int i=0 ; i<vectAll.size() ; i++)
		 {
			 tmp = ConstantValue.patTab.split(vectAll.get(i));
			 
			 setCell.add(tmp[1]);
		 }
		 
		 System.out.println("Total cell folder need to create: " + setCell.size());
	}
	
	
	// bedtools intersect -s  -wo  -a a.bed -b b.bed > result.bed
	
	void loadFilesToRead()
	{
		vectInputFiles = new Vector<String>();
		vectOutputFiles = new Vector<String>();
		
		String[] arr = (String[]) setCell.toArray(new String[setCell.size()]);
		int setSize = arr.length;
		
		
		
		 String tmp[];
		 String inFullpathCAGE,outFullPath, outNewFold;
		 
		 
		 String headString= CommonFunction.readlinesOfAfileAsBuffer(this.fnmHeaderShell);
		 
		 StringBuffer bedCommands = new StringBuffer();
		 
		 bedCommands.append(headString+"\n\n\n");
		 
		 for(int i=0 ; i< setSize ; i++)
		 {
			 
			 
			 inFullpathCAGE = this.foldInputCAGE+ 
					 			arr[i] + "/" + 
					 			this.fnmTwoCAGEBed;
			 vectInputFiles.add(inFullpathCAGE);
			 
			 
			 FolderOperations.create_new_folder(this.foldOutputResult);
			 outNewFold = this.foldOutputResult+ arr[i];
			 FolderOperations.create_new_folder(outNewFold);
			 
			 outFullPath =  outNewFold + "/" +  
					 		CommonFunction.getFilenameFromAbsolutepath(this.fnmOnePromBed) +
					 		".cage.intersect.bed";
			 vectOutputFiles.add(outFullPath);
			 
			 
			 System.out.println("File to read: " +   inFullpathCAGE);
			 System.out.println("File to write: " +  outFullPath);
			 
			 bedCommands.append("bedtools  intersect  -s  -wo " +
			 " -a  " + this.fnmOnePromBed   + 
			 " -b  " + inFullpathCAGE  + 
			 "  > "  + outFullPath +
			 " \n");
			 
		 }
		 
		 
		 
		 
		 CommonFunction.writeContentToFile(this.fnmCommandOutput , bedCommands +"");
		 
		 
	}
	
	void doProcessing()
	{
		
		loadUniqueCellLines();
		loadFilesToRead();
	}
	
	
	
	
//	public Caller_CAGE_Cellspecific(String fnmFile_Cellline,
//			String foldInputCAGE, String foldOutputResult,
//			String fnmOnePromBed, String upstream, String downstream, String cHOICE,
//			
//			String isPromoterInput) {
//		super();
//		this.fnmFile_Cellline = fnmFile_Cellline;
//		this.foldInputCAGE = foldInputCAGE;
//		this.foldOutputResult = foldOutputResult;
//		this.fnmOnePromBed = fnmOnePromBed;
//		this.upstream = Integer.parseInt( upstream );
//		this.downstream =  Integer.parseInt( downstream );
//		this.CHOICE =  Integer.parseInt( cHOICE );
//		if( Integer.parseInt(isPromoterInput)==1)
//		{
//			System.out.println("Input is promoter, Not TSS");
//			this.isPromoterInput = true;
//			this.upstream    = 0;
//			this.downstream  = 0 ;
//
//		}else
//		{
//			this.isPromoterInput = false;
//		}
//	}


	public Command_Caller_CAGE_Cellspecific(String fnmFile_Cellline,
			String foldInputCAGE, String foldOutputResult,
			String fnmOnePromBed, String fnmTwoCAGEBed,
			String fnmCommandOutput, String fnmHeaderShell) {
		super();
		this.fnmFile_Cellline = fnmFile_Cellline;
		this.foldInputCAGE = foldInputCAGE;
		this.foldOutputResult = foldOutputResult;
		this.fnmOnePromBed = fnmOnePromBed;
		this.fnmTwoCAGEBed = fnmTwoCAGEBed;
		this.fnmCommandOutput = fnmCommandOutput;
		this.fnmHeaderShell = fnmHeaderShell;
	}



	public static void main(String[] args) {
		
		
		
//		Caller_CAGE_Cellspecific obj = new Caller_CAGE_Cellspecific(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
		
//		Caller_CAGE_Cellspecific obj = new Caller_CAGE_Cellspecific("EncodeCage_FileNames_CellLine_Tissue_Hg19.txt", 
//				"./bin/", 
//				"./outFold/", 
//				"inputGene.bed", 
//				"500"doProcessing, 
//				"500", 
//				"3", 
//				"0");
		
//	
//		Caller_CAGE_Cellspecific obj = new Caller_CAGE_Cellspecific("EncodeCage_FileNames_CellLine_Tissue_Hg19.txt", 
//		"./bin/", 
//		"./outFold/", 
//		"./inputGene.bed" ,
//		""
//		"./command.sh" ,
		// "headerShell.txt");
		
		Command_Caller_CAGE_Cellspecific obj = new Command_Caller_CAGE_Cellspecific(args[0], args[1], args[2], args[3], args[4] , args[5] , args[6] );
		
		
		obj.doProcessing();
		

	}



	
}



